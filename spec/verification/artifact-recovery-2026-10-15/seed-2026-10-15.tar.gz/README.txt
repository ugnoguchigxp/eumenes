Eumenes Seed snapshot — 2026-10-15

Contents: reusable Seed sources (builtin instructions, bundles, catalog, contracts and loaders), source SHA-256 manifest, generated catalog hash manifest and validation results.
145 definitions and 84 documents can be generated through the existing Seed loader.
This is a source snapshot for a compatible Eumenes checkout, not a standalone application or a database backup. It excludes user conversations, generated artifacts, credentials and connection settings. Historical revisions present only in an existing installation are not exported.

Restore:
1. Check the archive against the adjacent .sha256 file.
2. Extract into a separate staging directory. Verify every source file using seed-files-manifest.json before applying any file.
3. Compare with the target checkout and apply reviewed Seed sources. Preserve local changes and existing data. Use the normal capability seeding/import path; do not insert SQL or overwrite immutable revisions.
4. In the compatible checkout with dependencies installed, run:
   bun test api/domains/capabilities/test api/application/capability-seed.test.ts api/application/capability-upgrade.test.ts
5. Use the normal application startup to register the Seed. Check the artifact catalog and relevant profiles/skills. If a new revision conflict is reported, investigate and publish a new revision; do not replace stored historical bodies.

Validation: fresh initialization passes; second Seed leaves the catalog unchanged; re-seeding an isolated clone of the restored installation leaves every catalog row unchanged; all 17 bundles have no import issues or pending registrations. All active definition IDs and hashes, and all supplied document hashes, match the restored installation.
One installed inactive historical skill:web.research@3 variant differs from the canonical published Seed. The existing superseded-builtin policy preserves it without conflict. Both hashes are recorded in seed-verification.json; neither the published old Seed body nor the installed old body was overwritten.

Scope: offline catalog tests and read-only live catalog verification. Global formatting/typecheck limitations are documented in the adjacent recovery README.md.
