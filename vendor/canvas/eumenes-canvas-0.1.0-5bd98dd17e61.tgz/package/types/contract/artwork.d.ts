export declare const CONTRACT_VERSION = "canvas-artwork/1";
/** ページ直接モード（runtime: "page"）の作品の契約の版（docs/artwork-contract-v2-page.md）。設定で有効なときだけ受け付ける。 */
export declare const PAGE_CONTRACT_VERSION = "canvas-artwork/2";
export declare const MAX_ENTRY_BYTES: number;
export declare const MAX_DATA_BYTES: number;
export declare const MAX_TITLE_CHARS = 80;
export interface ArtworkBody {
    title: string;
    entry: string;
    /** ホストが登録した読み取り専用データの参照（任意）。 */
    dataRef?: string;
    /** ホストが同梱する固定版ライブラリの id（任意。例 "three@0.187.0"）。 */
    libraries?: string[];
    /** ページ直接モードの作品だけ "page"（design.md §8）。無い作品は Worker の方式。 */
    runtime?: "page";
}
export interface ContractResult {
    ok: boolean;
    errors: string[];
}
export declare function utf8Bytes(s: string): number;
export interface CheckOptions {
    /** ページ直接モードを受け付けるか（既定 false。false のとき runtime は従来どおり未定義の項目として拒否する）。 */
    pageMode?: boolean;
}
export declare function checkArtwork(body: unknown, opts?: CheckOptions): ContractResult;
export declare function checkData(data: unknown): ContractResult;
/** ホストが保存した実体と契約の版から digest を計算する。 */
export declare function artworkDigest(body: ArtworkBody): Promise<string>;
export declare function sha256Hex(s: string): Promise<string>;
