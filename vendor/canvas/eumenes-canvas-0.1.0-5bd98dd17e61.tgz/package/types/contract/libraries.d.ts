export interface HostLibrary {
    /** 作品が宣言する id（名前@版）。 */
    id: string;
    /** npm のパッケージ名と固定版（package.json は exact で固定）。 */
    pkg: string;
    version: string;
    /** 作品の関数本体に渡す引数名。 */
    param: string;
    /** プレビューが束ねる shim（src/preview/libs/ からの相対）。 */
    shim: string;
}
export declare const HOST_LIBRARIES: readonly HostLibrary[];
export declare const MAX_LIBRARIES = 4;
export declare function libraryById(id: string): HostLibrary | undefined;
/** 宣言の順ではなく登録の順に並べる（連結順と引数の順を宣言の書き方によらず一定にする）。 */
export declare function resolveLibraries(ids: readonly string[] | undefined): HostLibrary[];
