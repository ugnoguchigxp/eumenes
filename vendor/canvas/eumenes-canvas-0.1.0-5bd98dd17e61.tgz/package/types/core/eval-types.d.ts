import { type MakerSpec } from "./spec";
export type Step = {
    do: "wait";
    ms: number;
} | {
    do: "keyDown";
    input: string;
} | {
    do: "keyUp";
    input: string;
} | {
    do: "tap";
    input: string;
    holdMs: number;
} | {
    do: "click";
    x: number;
    y: number;
} | {
    do: "drag";
    from: [number, number];
    to: [number, number];
    ms: number;
} | {
    do: "shot";
    label: string;
} | {
    do: "track";
    color: string;
    label: string;
};
export interface Script {
    id: string;
    requirement: string | null;
    purpose: string;
    seed: number;
    steps: Step[];
}
export interface EvalPlan {
    scripts: Script[];
}
export declare const PLAN_LIMITS: {
    readonly scripts: 6;
    readonly steps: 30;
    readonly waitMsPerStep: 10000;
    readonly waitMsPerScript: 30000;
    readonly measuresPerScript: 12;
};
/** 台本を正規化する。測定の無い台本は捨て、残った台本に S1・S2… と id を振る。 */
export declare function normalizePlan(raw: unknown, spec: MakerSpec | null): EvalPlan;
export type VerdictValue = "pass" | "fail" | "unknown";
export interface RequirementVerdict {
    requirement: string;
    verdict: VerdictValue;
    evidence: string[];
    note: string;
}
export interface Issue {
    severity: "blocking" | "minor";
    requirement: string | null;
    symptom: string;
    evidence: string[];
    suggestion: string;
}
export interface EvalVerdict {
    verdicts: RequirementVerdict[];
    issues: Issue[];
    summary: string;
}
/** コードを読んだだけの根拠。fail・指摘には使えるが、pass の根拠にはならない。 */
export declare const CODE_EVIDENCE: Set<string>;
/** 判定を正規化する。甘い判定を止める中心の規則。 */
export declare function normalizeVerdict(raw: unknown, spec: MakerSpec, evidenceIds: ReadonlySet<string>): EvalVerdict;
