import type { ArtworkBody } from "../contract/artwork";
import type { MakerSpec } from "./spec";
import type { Turn } from "./types";
export interface EvalPlanInput {
    request: string;
    conversation: Turn[];
    hasBase: boolean;
    spec: MakerSpec;
    probeText: string;
}
export interface EvalJudgeInput {
    request: string;
    conversation: Turn[];
    spec: MakerSpec;
    body: ArtworkBody;
    probeText: string;
    scriptText: string;
    diffText: string | null;
    evidenceIds: string[];
}
export interface EvaluatorPort {
    readonly label: string;
    plan(input: EvalPlanInput, signal: AbortSignal): Promise<unknown>;
    judge(input: EvalJudgeInput, signal: AbortSignal, maxRetries?: number): Promise<unknown>;
}
