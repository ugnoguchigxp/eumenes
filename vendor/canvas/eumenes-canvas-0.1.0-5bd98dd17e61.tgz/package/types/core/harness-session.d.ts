import type { Browser } from "@playwright/test";
import type { ArtworkBody } from "../contract/artwork";
import type { Shot } from "./pixels";
export type IssueToken = (body: ArtworkBody) => string;
export interface StartResult {
    type: string;
    message?: string;
}
/** 観測ごとの文脈を分けながら、起動中・接続中の Chromium を再利用する。 */
export declare class ObservationBrowser {
    private launchArgs;
    private handleProcessSignals;
    private connection;
    constructor(launchArgs: string[], handleProcessSignals?: boolean);
    get(): Promise<Browser>;
    close(): Promise<void>;
}
/** 入力の名前（KeyboardEvent.code の形）を Playwright のキー名にする。KeyR → r、Digit1 → 1、ほかはそのまま。 */
export declare function playwrightKey(input: string): string;
export declare class HarnessSession {
    private browser;
    private hostOrigin;
    private issue;
    /** 起動から進めた時刻（ms）。 */
    t: number;
    private ctx;
    private page;
    /** この起動より前の通知を読まないための位置。 */
    private eventsFrom;
    constructor(browser: Browser, hostOrigin: string, issue: IssueToken);
    private p;
    open(signal?: AbortSignal): Promise<void>;
    start(body: ArtworkBody, data: unknown, seed?: number): Promise<StartResult>;
    /** 入力やリサイズがシェルに届く前に時間を進めないよう、シェルの requestAnimationFrame を 2 回待つ。 */
    private settle;
    advance(ms: number): Promise<void>;
    poke(count: number): Promise<void>;
    shot(): Promise<Shot>;
    keyDown(input: string): Promise<void>;
    keyUp(input: string): Promise<void>;
    click(x: number, y: number): Promise<void>;
    drag(from: [number, number], to: [number, number], ms: number): Promise<void>;
    setNarrow(on: boolean): Promise<void>;
    errors(): Promise<string[]>;
    close(): Promise<void>;
}
