export interface InferenceRequest {
    purpose: string;
    system: string;
    prompt: string;
    outputSchema: unknown;
    maxOutputChars?: number;
    images?: readonly {
        mediaType: "image/png" | "image/jpeg";
        bytes: Uint8Array;
    }[];
}
export type Validate<T> = (value: unknown) => {
    ok: true;
    value: T;
} | {
    ok: false;
    issues: unknown;
};
export interface InferenceChannel {
    /** 形の違う応答は、理由を付けて出し直す（最大 maxRetries 回）。それでも違えば例外。 */
    complete<T>(req: InferenceRequest, validate: Validate<T>, signal: AbortSignal, maxRetries?: number): Promise<T>;
}
