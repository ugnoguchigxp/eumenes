/** 文の中の「（作品の N 行 M 列）」すべての直後に「［該当行: <作品の N 行目>］」を足す。行が無い・空白だけなら足さない。 */
export declare function withSourceLine(message: string, entry: string): string;
/** 作品本体の構文エラーの位置と該当行。エラーが無い・位置が取れない・Bun 以外の環境では null。 */
export declare function syntaxErrorDetail(entry: string): string | null;
