export declare const MAKER_SKILL_PATH: string;
export interface MakerSkill {
    name: string;
    description: string;
    /** frontmatter を除いた本文。 */
    body: string;
}
/** SKILL 形式（--- で囲んだ frontmatter に name・description）の文書を読む。形が違えば例外。 */
export declare function parseMakerSkill(text: string): MakerSkill;
export declare function loadMakerSkill(path?: string): MakerSkill;
/** 役割の短い前置き＋手順の本文。応答の形（JSON の項目）は呼び出し側の前置きで指定する。 */
export declare function makerSystemPrompt(skill: MakerSkill, preamble: string): string;
export declare const makerSkillPathFrom: (root: string) => string;
