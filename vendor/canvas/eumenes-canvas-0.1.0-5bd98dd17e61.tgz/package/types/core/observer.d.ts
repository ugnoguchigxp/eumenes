import type { ArtworkBody } from "../contract/artwork";
import type { Control } from "./spec";
import type { CheckResult, Observation } from "./types";
export interface ObservationResult {
    environment: string;
    checks: CheckResult[];
    observations: Observation[];
}
export interface ObserverPort {
    readonly suite: string;
    observe(body: ArtworkBody, data: unknown, signal: AbortSignal, controls?: readonly Control[]): Promise<ObservationResult>;
    close(): Promise<void>;
}
/** host-smoke/3：宣言されたキーを実行する。キーの宣言が無い作品には従来の入力を使う。 */
export declare const OBSERVER_SUITE = "host-smoke/3";
/** 描画領域のクリックの上限。 */
export declare const PAINTED_CLICKS = 16;
type IssueToken = (body: ArtworkBody) => string;
/** Playwright（Chromium）で検証ホストのハーネスを開いて観測する。 */
export declare class PlaywrightObserver implements ObserverPort {
    private hostOrigin;
    private issue;
    readonly suite = "host-smoke/3";
    private readonly browser;
    constructor(hostOrigin: string, issue: IssueToken, launchArgs?: string[], handleProcessSignals?: boolean);
    observe(body: ArtworkBody, data: unknown, signal: AbortSignal, controls?: readonly Control[]): Promise<ObservationResult>;
    close(): Promise<void>;
}
/**
 * 作品が描いた領域の代表点。最も多い色を背景とし、背景と違う画素が 3 個以上ある 8px のセルを 8 近傍でまとめる。
 * 画面の 1/4 を超えるまとまり（背景の一部とみなす）は除き、大きい順に最大 max 個。
 * 代表点は、まとまりの重心に最も近いセルの中で、セル中心に最も近い背景でない画素。
 */
export declare function paintedTargets(png: {
    width: number;
    height: number;
    data: Buffer | Uint8Array;
}, max: number): {
    x: number;
    y: number;
}[];
export {};
