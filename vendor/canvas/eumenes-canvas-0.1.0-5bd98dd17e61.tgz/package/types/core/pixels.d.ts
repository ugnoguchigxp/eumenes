export interface Shot {
    width: number;
    height: number;
    data: Uint8Array;
}
export interface Box {
    x: number;
    y: number;
    w: number;
    h: number;
}
export interface DiffResult {
    pixels: number;
    box: Box | null;
}
export interface SceneItem {
    color: string;
    box: Box;
    area: number;
}
export interface Scene {
    width: number;
    height: number;
    background: string;
    items: SceneItem[];
    omitted: number;
}
export interface BlobResult {
    pixels: number;
    box: Box | null;
    cx: number | null;
    cy: number | null;
}
export declare function rgbHex(r: number, g: number, b: number): string;
export declare function parseHex(h: string): [number, number, number] | null;
/** RGB のどれかが違う画素の数と外接矩形。寸法が違えば全面が違うとみなす。 */
export declare function diffShots(a: Shot, b: Shot): DiffResult;
/** 最も多い色（0xRRGGBB）。全画素を数える。同数なら数値の小さい色。 */
export declare function dominantColor(s: Shot): number;
export declare function isSingleColor(s: Shot): boolean;
/** 各チャンネルの差が tol 以下の画素の数・外接矩形・重心（小数 1 桁）。 */
export declare function blobOf(s: Shot, color: number, tol?: number): BlobResult;
/**
 * 画面の要約：背景（最も多い色）から離れた画素を、色の鍵（各チャンネルの上位 3 ビット）が同じで上下左右に隣り合うまとまりにする。
 * 画素単位で行う（升目にまとめると少数派の色の画素が欠け、面積と外接矩形がずれる）。
 */
export declare function describeScene(s: Shot, maxItems?: number): Scene;
/** 画面の要約を 1 行の文にする。 */
export declare function sceneText(scene: Scene): string;
