import type { EvalJudgeInput, EvalPlanInput, EvaluatorPort } from "./evaluator-port";
import type { InferenceChannel } from "./inference";
export declare const EVALUATOR_SKILL_PATH: string;
export declare const EVALUATOR_PREAMBLE: string;
/** 検証担当の system：前置き＋検証の手順（docs/evaluator-skill.md）。 */
export declare function evaluatorSystem(): string;
export declare const PLAN_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["scripts"];
    readonly properties: {
        readonly scripts: {
            readonly type: "array";
            readonly maxItems: 6;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["requirement", "purpose", "steps"];
                readonly properties: {
                    readonly requirement: {
                        readonly type: "string";
                        readonly description: "確かめる要件の id";
                    };
                    readonly purpose: {
                        readonly type: "string";
                        readonly maxLength: 120;
                    };
                    readonly steps: {
                        readonly type: "array";
                        readonly minItems: 1;
                        readonly maxItems: 30;
                        readonly items: {
                            readonly type: "object";
                            readonly additionalProperties: false;
                            readonly required: readonly ["do"];
                            readonly properties: {
                                readonly do: {
                                    readonly type: "string";
                                    readonly enum: string[];
                                };
                                readonly ms: {
                                    readonly type: "number";
                                };
                                readonly input: {
                                    readonly type: "string";
                                };
                                readonly holdMs: {
                                    readonly type: "number";
                                };
                                readonly x: {
                                    readonly type: "number";
                                };
                                readonly y: {
                                    readonly type: "number";
                                };
                                readonly from: {
                                    type: string;
                                    items: {
                                        type: string;
                                    };
                                    minItems: number;
                                    maxItems: number;
                                };
                                readonly to: {
                                    type: string;
                                    items: {
                                        type: string;
                                    };
                                    minItems: number;
                                    maxItems: number;
                                };
                                readonly color: {
                                    readonly type: "string";
                                };
                                readonly label: {
                                    readonly type: "string";
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
export declare const VERDICT_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["verdicts", "issues", "summary"];
    readonly properties: {
        readonly verdicts: {
            readonly type: "array";
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["requirement", "verdict", "evidence", "note"];
                readonly properties: {
                    readonly requirement: {
                        readonly type: "string";
                    };
                    readonly verdict: {
                        readonly type: "string";
                        readonly enum: readonly ["pass", "fail", "unknown"];
                    };
                    readonly evidence: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                    readonly note: {
                        readonly type: "string";
                    };
                };
            };
        };
        readonly issues: {
            readonly type: "array";
            readonly maxItems: 8;
            readonly items: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["severity", "symptom", "evidence", "suggestion"];
                readonly properties: {
                    readonly severity: {
                        readonly type: "string";
                        readonly enum: readonly ["blocking", "minor"];
                    };
                    readonly requirement: {
                        readonly type: "string";
                    };
                    readonly symptom: {
                        readonly type: "string";
                    };
                    readonly evidence: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                    readonly suggestion: {
                        readonly type: "string";
                    };
                };
            };
        };
        readonly summary: {
            readonly type: "string";
            readonly maxLength: 400;
        };
    };
};
/** 台本づくりのプロンプト。作品のコードは入れない。 */
export declare function planPrompt(input: EvalPlanInput): string;
/** 判定のプロンプト。観測・測定・差分・コードを渡す。 */
export declare function judgePrompt(input: EvalJudgeInput): string;
/** 1 回ずつの推論で台本と判定を返す検証担当。 */
export declare class PromptEvaluator implements EvaluatorPort {
    private channel;
    readonly label: string;
    private system;
    constructor(channel: InferenceChannel, o?: {
        label?: string;
        system?: string;
    });
    plan(input: EvalPlanInput, signal: AbortSignal): Promise<unknown>;
    judge(input: EvalJudgeInput, signal: AbortSignal, maxRetries?: number): Promise<unknown>;
}
