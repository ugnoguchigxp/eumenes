import type { InferenceChannel, Validate } from "./inference";
import { type GenerationInput, type GenerationOutput, type ModelPort } from "./model-port";
export declare const MAKER_PITFALLS_PATH: string;
/** 制作担当の出力の形。項目の順は title → spec → entry → …（宣言を作品より先に書かせる）。 */
export declare const MAKER_OUTPUT_SCHEMA: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly required: readonly ["title", "spec", "entry", "changes", "unconfirmed", "reply"];
    readonly properties: {
        readonly title: {
            readonly type: "string";
            readonly minLength: 1;
            readonly maxLength: 80;
            readonly description: "作品の題名";
        };
        readonly spec: {
            readonly type: "object";
            readonly additionalProperties: false;
            readonly required: readonly ["requirements", "controls"];
            readonly description: "作品を書く前に決める宣言。entry より先に書く";
            readonly properties: {
                readonly requirements: {
                    readonly type: "array";
                    readonly items: {
                        readonly type: "string";
                        readonly maxLength: 300;
                    };
                    readonly minItems: 1;
                    readonly maxItems: 20;
                    readonly description: "依頼に書かれた要件を 1 つずつ短い文にしたもの";
                };
                readonly controls: {
                    readonly type: "array";
                    readonly maxItems: 12;
                    readonly description: "作品の操作の一覧";
                    readonly items: {
                        readonly type: "object";
                        readonly additionalProperties: false;
                        readonly required: readonly ["kind", "action", "always"];
                        readonly properties: {
                            readonly kind: {
                                readonly type: "string";
                                readonly enum: readonly ["key", "pointer"];
                            };
                            readonly input: {
                                readonly type: "string";
                                readonly description: "kind が key のときだけ。KeyboardEvent.code の名前";
                            };
                            readonly action: {
                                readonly type: "string";
                                readonly maxLength: 100;
                                readonly description: "その操作で起きること";
                            };
                            readonly always: {
                                readonly type: "boolean";
                                readonly description: "起動直後から、いつ入力しても画面に変化が出る操作だけ true";
                            };
                        };
                    };
                };
            };
        };
        readonly entry: {
            readonly type: "string";
            readonly minLength: 1;
            readonly description: "作品の JavaScript 本文（公開された実行契約に従う）";
        };
        readonly dataRef: {
            readonly type: "string";
            readonly description: "登録データを使うときだけ、その ref";
        };
        readonly libraries: {
            readonly type: "array";
            readonly items: {
                readonly type: "string";
            };
            readonly maxItems: 4;
            readonly description: "同梱ライブラリを使うときだけ、その id（公開された実行契約の表。例 three@0.187.0）";
        };
        readonly changes: {
            readonly type: "string";
            readonly maxLength: 2000;
            readonly description: "変更内容の説明";
        };
        readonly unconfirmed: {
            readonly type: "array";
            readonly items: {
                readonly type: "string";
            };
            readonly maxItems: 20;
            readonly description: "依頼のうち確かめられていない点";
        };
        readonly reply: {
            readonly type: "string";
            readonly maxLength: 2000;
            readonly description: "利用者への返答";
        };
    };
};
/** 役割・応答の形・宣言の書き方の前置き。振る舞いの規則は docs/maker-skill.md（制作手順）に置く。 */
export declare const MAKER_PREAMBLE: string;
/** 制作担当の system：前置き＋制作手順（docs/maker-skill.md）＋（あれば）落とし穴の付録（docs/maker-pitfalls.md）。 */
export declare function makerSystem(): string;
export declare const SAVED_BASE_GUIDANCE = "\u3053\u306E\u672C\u6587\u306F\u3001\u4ECA\u56DE\u306E\u4F9D\u983C\u306E\u76F4\u524D\u306B\u9078\u3070\u308C\u3066\u3044\u308B\u7DE8\u96C6\u5143\u3067\u3059\u3002\u4ECA\u56DE\u306E\u4F9D\u983C\u3067\u7DAD\u6301\u3059\u308B\u3088\u3046\u6307\u5B9A\u3055\u308C\u305F\u65E2\u5B58\u306E\u5024\u3084\u6319\u52D5\u306F\u3001\u3053\u306E\u7248\u306E\u30B3\u30FC\u30C9\u304B\u3089\u5F15\u304D\u7D99\u304E\u307E\u3059\u3002\u4EE5\u524D\u306E\u4F9D\u983C\u3067\u3059\u3067\u306B\u9069\u7528\u3057\u305F\u5897\u6E1B\u3092\u91CD\u306D\u3066\u9069\u7528\u3057\u307E\u305B\u3093\u3002";
/** 制作担当のプロンプト。条件 D の directPrompt と同じ並び・見出しで、前の候補の節だけが 2 通り。 */
export declare function makerPrompt(input: GenerationInput): string;
/** 応答の検査。条件 D の validateArtwork と同じ検査に spec の検査を足す。spec は受け取った値をそのまま入れる（正規化はサービスが行う）。 */
export declare const validateMakerOutput: Validate<GenerationOutput>;
/** 1 回の推論で作品と宣言を返す制作担当。 */
export declare class PromptMaker implements ModelPort {
    private channel;
    readonly label: string;
    private system;
    constructor(channel: InferenceChannel, o?: {
        label?: string;
        system?: string;
    });
    generate(input: GenerationInput, signal: AbortSignal): Promise<GenerationOutput>;
}
