import type { ArtworkBody } from "../contract/artwork";
import type { Script } from "./eval-types";
import type { HarnessSession } from "./harness-session";
export interface Measure {
    id: string;
    t: number;
    kind: "shot" | "track";
    label: string;
    text: string;
}
export interface ScriptResult {
    id: string;
    requirement: string | null;
    purpose: string;
    measures: Measure[];
    errors: string[];
    skipped: string | null;
}
/** 台本 1 本を実行する。途中で例外が出たら、そこまでの測定を返す。 */
export declare function runScript(s: HarnessSession, body: ArtworkBody, data: unknown, script: Script): Promise<ScriptResult>;
/** 測定の文。各行の先頭が証拠 id。 */
export declare function scriptText(results: ScriptResult[]): string;
/** 検証担当が引用できる測定の id。エラーがある台本は「<id>-errors」も足す。 */
export declare function scriptEvidenceIds(results: ScriptResult[]): string[];
