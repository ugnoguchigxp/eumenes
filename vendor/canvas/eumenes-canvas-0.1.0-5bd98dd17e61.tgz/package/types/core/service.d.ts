import { type ArtworkBody } from "../contract/artwork";
import type { DatasetInfo, ModelPort } from "./model-port";
import type { ObserverPort } from "./observer";
import { type ReviewerPort, type ReviewMode } from "./review";
import type { Store } from "./store";
import type { CheckResult, Run, Turn } from "./types";
export declare const MAX_FIX_ATTEMPTS = 2;
export declare const MAX_TURN_INFERENCES = 6;
/** 期限までの残りがこれより短いときは検証を始めない。 */
export declare const REVIEW_MIN_REMAINING_MS = 45000;
export interface Dataset extends DatasetInfo {
    data: unknown;
}
export interface ServiceOptions {
    /** 単一利用者モード。記録の owner を照合せず、全作品・実行・候補を見せる（design.md §3）。 */
    singleUser?: boolean;
    store: Store;
    model: ModelPort;
    observer: ObserverPort;
    contract: string;
    datasets?: Dataset[];
    runTimeoutMs?: number;
    now?: () => number;
    /** 候補の検証。省略・mode が off なら従来どおり（必須の検査に通った最初の候補を提示する）。 */
    review?: {
        reviewer: ReviewerPort;
        mode: ReviewMode;
        maxReviews?: number;
    };
    /** ページ直接モード（design.md §8）の作品を受け付けるか。既定は偽（runtime は契約の未定義の項目として不合格）。 */
    pageMode?: boolean;
}
export declare class ServiceError extends Error {
    status: number;
    extra: Record<string, unknown>;
    constructor(status: number, message: string, extra?: Record<string, unknown>);
}
export declare class CanvasService {
    private o;
    private aborts;
    private timers;
    private closeTask?;
    private admitting;
    private expiring;
    private datasets;
    private now;
    readonly runTimeoutMs: number;
    /** 実行中の生成（試験で完了を待つため）。 */
    readonly inflight: Map<string, Promise<void>>;
    constructor(o: ServiceOptions);
    datasetFor(body: ArtworkBody): unknown;
    /** 記録の所有者が要求者と一致するか。単一利用者モードでは常に真（既存記録の owner は書き換えずに無視する）。 */
    private sees;
    private ownArtwork;
    startRun(owner: string, session: string, req: {
        message: string;
        artworkId?: string | null;
        conversation?: Turn[];
    }): Promise<Run>;
    /** 実行が受付時の状態のままで、結果を採用できるか。 */
    private live;
    private expire;
    cancelRun(owner: string, runId: string): Promise<Run>;
    getRun(owner: string, runId: string): {
        candidates: {
            id: string;
            runId: string;
            artworkId: string;
            baseRevision: number;
            attempt: number;
            title: string;
            digest: string;
            changes: string;
            unconfirmed: string[];
            reply: string;
            verification: {
                id: string;
                requiredPassed: boolean;
                checks: CheckResult[];
                failedAt: string | null;
                environment: string;
            } | null;
            spec: import("./spec").MakerSpec | null;
            review: import("./review").CandidateReview | null;
        }[];
        id: string;
        owner: string;
        session: string;
        artworkId: string;
        isNew: boolean;
        baseRevision: number;
        baseDigest: string | null;
        generation: number;
        request: {
            message: string;
            conversation: Turn[];
        };
        state: import("./types").RunState;
        deadline: number;
        attempts: number;
        candidateIds: string[];
        presentedCandidateId: string | null;
        failure: string | null;
        createdAt: number;
        finishedAt: number | null;
    };
    private candidateView;
    private execute;
    private present;
    private markPresented;
    private finish;
    private makeVerification;
    private replayReceipt;
    save(owner: string, candidateId: string, req: {
        expectedRevision: number;
        idempotencyKey: string;
    }): Promise<{
        status: number;
        result: unknown;
        replay: boolean;
    }>;
    restore(owner: string, artworkId: string, req: {
        revision: number;
        expectedRevision: number;
        idempotencyKey: string;
    }): Promise<{
        status: number;
        result: unknown;
        replay: boolean;
    }>;
    listArtworks(owner: string): {
        id: string;
        title: string;
        currentRevision: number;
        updatedAt: number;
    }[];
    getArtwork(owner: string, artworkId: string): {
        revisions: {
            revision: number;
            parent: number | null;
            digest: string;
            restoredFrom: number | null;
            title: string;
            createdAt: number;
        }[];
        id: string;
        owner: string;
        title: string;
        currentRevision: number;
        createdAt: number;
        updatedAt: number;
    };
    /** プレビュー対象の実体を解決する。所有者を照合し、保存版か提示中の候補だけを返す。 */
    resolvePreview(owner: string, src: {
        candidateId?: string;
        artworkId?: string;
        revision?: number;
    }): {
        body: ArtworkBody;
        data: unknown;
    };
    drain(): Promise<void>;
    /** 実行中の作業を止め、観測器（Playwright のブラウザなど）を閉じる。 */
    close(): Promise<void>;
}
