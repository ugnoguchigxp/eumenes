/** 宣言・台本で使える入力名（KeyboardEvent.code）。Tab と Escape はホストが使うので入れない。 */
export declare const INPUT_RE: RegExp;
/** 観測のときの作品の面の寸法（CSS ピクセル）。 */
export declare const FRAME_W = 480;
export declare const FRAME_H = 360;
export interface Requirement {
    id: string;
    text: string;
}
export interface Control {
    kind: "key" | "pointer";
    input: string;
    action: string;
    always: boolean;
}
export interface MakerSpec {
    requirements: Requirement[];
    controls: Control[];
}
/** 文字列で、前後の空白を除いて空でなければ max 文字で切って返す。そうでなければ null。 */
export declare function str(v: unknown, max: number): string | null;
/** 物（null でも配列でもない object）ならそのまま、そうでなければ null。 */
export declare function obj(v: unknown): Record<string, unknown> | null;
/** 有限の数で lo 以上 hi 以下なら四捨五入して返す。そうでなければ null。 */
export declare function int(v: unknown, lo: number, hi: number): number | null;
/** モデルの出力を、形の合う部分だけ残して MakerSpec にする（内容は書き換えない）。要件が 0 個なら null。 */
export declare function normalizeSpec(raw: unknown): MakerSpec | null;
