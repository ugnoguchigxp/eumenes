import type { Artwork, Candidate, Revision, Run, SaveReceipt, Verification } from "./types";
interface State {
    version: 1;
    artworks: Record<string, Artwork>;
    revisions: Record<string, Revision[]>;
    runs: Record<string, Run>;
    candidates: Record<string, Candidate>;
    verifications: Record<string, Verification>;
    receipts: Record<string, SaveReceipt>;
    sessions: Record<string, number>;
}
type Collection = Exclude<keyof State, "version">;
type Commit = <K extends Collection, T>(collections: readonly K[], mutate: (s: Pick<State, K>) => T) => Promise<T>;
export declare class Store {
    private s;
    private file;
    private writes;
    private readonly sealed;
    private readonly encodedHistory;
    constructor(dataDir: string | null);
    /** 古い版・候補を共有し、変更は作業用の表での置換・追記に限る。 */
    private seal;
    private encode;
    private flush;
    /** 最新版を照合する処理から永続化までを順番に行う。照合だけで終える操作もある。 */
    write<T>(operation: (commit: Commit) => T | Promise<T>): Promise<T>;
    idle(): Promise<void>;
    /** 更新対象だけを複製し、ファイルの置換に成功してから公開する。 */
    private commit;
    get artworks(): Record<string, Artwork>;
    get runs(): Record<string, Run>;
    get candidates(): Record<string, Candidate>;
    get verifications(): Record<string, Verification>;
    revisionsOf(artworkId: string): readonly Revision[];
    receipt(owner: string, key: string): SaveReceipt | undefined;
    putReceipt(s: Pick<State, "receipts">, r: SaveReceipt): void;
    nextGeneration(s: Pick<State, "sessions">, owner: string, session: string, artworkId: string): number;
    pushRevision(s: Pick<State, "revisions">, r: Revision): void;
}
export {};
