/** ループ本体の入口に実時間の検査を足す。元の行数と保存内容は維持する。 */
export declare function instrumentLoops(entry: string): string;
