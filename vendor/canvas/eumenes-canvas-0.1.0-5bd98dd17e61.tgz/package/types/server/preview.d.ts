import type { ArtworkBody } from "../contract/artwork";
import { type HostLibrary } from "../contract/libraries";
export declare const WORKER_CSP = "default-src 'none'";
/**
 * シェルの CSP。pageMode（ページ直接モード、design.md §8）が有効なときだけ、同じオリジンの内側の iframe（/p/<token>）を許す。
 * 無効なときは従来と同じ（frame-src の指定は無く、default-src 'none' で iframe を置けない）。
 */
export declare function shellCsp(hostOrigin: string, pageMode?: boolean): string;
/**
 * ページ直接モードの作品の文書の CSP（10 §2 の案）。script-src は 'self'（不透明オリジンでは何にも一致しない）ではなくプレビューオリジンを明示する。
 * 通信・Worker・入れ子の iframe・フォームの送信は止める。WebRTC は CSP では止まらない（design.md §8 で受け入れた残る危険）。
 */
export declare function pageCsp(previewOrigin: string, hostOrigin: string): string;
/** 作品の文書：画面いっぱいの canvas と固定の実行時コードだけ。作品の本文は実行時コードが初期化を受けてから読み込む。 */
export declare function pageDocument(previewOrigin: string): string;
/**
 * ページ直接モードの作品の本文：宣言されたライブラリ（IIFE）→ ライブラリを大域の名前（THREE・CANNON）に置く → 作品（普通のスクリプト）。
 */
export declare function assemblePageScript(entry: string, libs?: LibrarySource[]): string;
export interface LibrarySource {
    lib: HostLibrary;
    /** IIFE に束ねた本体（__canvasLibs[shim 名] に名前空間を置く）。 */
    source: string;
}
/**
 * Worker スクリプト：固定ブートストラップ → 宣言されたライブラリ → 作品本体（strict の関数本体）。
 * ライブラリは作品の引数（THREE・CANNON など）として渡す。宣言しない作品の組み立ては従来と同じ。
 */
export declare function assembleWorkerScript(entry: string, libs?: LibrarySource[]): string;
/** shim が名前空間を置く __canvasLibs のキー（src/preview/libs/*.js と一致）。 */
export declare function libKey(l: HostLibrary): string;
/** node_modules の固定版から IIFE を束ねる（初回だけ、以後はメモリに保持）。版が固定と違えば失敗にする。 */
export declare function librarySource(lib: HostLibrary): Promise<string>;
export declare function loadLibraries(ids: readonly string[] | undefined): Promise<LibrarySource[]>;
/** 作品本体を一度だけ取り出せる短命トークン。 */
export declare class PreviewTokens {
    private ttlMs;
    private now;
    private map;
    constructor(ttlMs?: number, now?: () => number);
    issue(body: ArtworkBody): string;
    /** トークンの方式（消費しない）。無い・期限切れは null。 */
    runtimeOf(token: string): "worker" | "page" | null;
    /** ページ直接モード：作品の文書を 1 回だけ返してよいかを確かめて印を付ける。 */
    servePageDoc(token: string): boolean;
    take(token: string): string | null;
    /** 作品本体と宣言したライブラリを一度だけ取り出す。 */
    takeRun(token: string): {
        entry: string;
        libraries: string[];
    } | null;
    /** ページ直接モード：作品の文書を返した後に、本文を一度だけ取り出す。 */
    takePageRun(token: string): {
        entry: string;
        libraries: string[];
    } | null;
    private sweep;
}
export declare function previewHandler(opts: {
    hostOrigin: string;
    tokens: PreviewTokens;
    pageMode?: boolean;
}): (req: Request) => Promise<Response>;
