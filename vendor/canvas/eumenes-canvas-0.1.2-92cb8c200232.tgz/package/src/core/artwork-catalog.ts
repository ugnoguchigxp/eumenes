import { createHash, randomBytes } from "node:crypto";
import { ServiceError, type CanvasService } from "./service";
import type { ArtworkBase } from "./types";

type Target = { owner: string; scope: string; artworkId: string; expectedBase: ArtworkBase; expiresAt: number };

/** 会話に提示した対象と版の参照。制作受付後はジョブが編集元を保持する。 */
export class ArtworkCatalog {
  private targets = new Map<string, Target>();
  private shown = new Map<string, { refs: string[]; hasMore: boolean; nextCursor: string | null; expiresAt: number }>();
  constructor(private service: CanvasService, private now = () => Date.now()) {}

  page(owner: string, scope: string, input: { query?: string; cursor?: string } = {}) {
    const query = (input.query ?? "").normalize("NFKC").toLocaleLowerCase();
    if (query.length > 200) throw new ServiceError(400, "検索語の上限");
    const rows = this.service.listArtworks(owner).filter((a) => a.title.normalize("NFKC").toLocaleLowerCase().includes(query));
    const fingerprint = createHash("sha256").update(JSON.stringify(rows)).digest("hex");
    let offset = 0;
    if (input.cursor) {
      let cursor;
      try { cursor = JSON.parse(Buffer.from(input.cursor, "base64url").toString("utf8")); }
      catch { throw new ServiceError(400, "ページ参照の形式"); }
      if (!cursor || typeof cursor !== "object" || Array.isArray(cursor)) throw new ServiceError(400, "ページ参照の形式");
      if (cursor.fingerprint !== fingerprint || cursor.query !== query) throw new ServiceError(409, "一覧が更新されました。検索し直してください", { code: "catalog-changed" });
      if (!Number.isSafeInteger(cursor.offset) || cursor.offset < 0 || cursor.offset > rows.length) throw new ServiceError(400, "ページ参照の範囲");
      offset = cursor.offset;
    }
    for (const [ref, target] of this.targets) if (target.expiresAt <= this.now()) this.targets.delete(ref);
    const page = rows.slice(offset, offset + 25);
    if (this.targets.size + page.length > 2048) throw new ServiceError(429, "対象参照の上限。しばらく待って検索し直してください");
    const artworks = page.map((a) => {
      const revision = this.service.getArtwork(owner, a.id).revisions.find((r) => r.revision === a.currentRevision)!;
      const targetRef = "ct_" + randomBytes(12).toString("base64url");
      this.targets.set(targetRef, { owner, scope, artworkId: a.id, expectedBase: { revision: revision.revision, digest: revision.digest }, expiresAt: this.now() + 180_000 });
      return { artworkId: a.id, title: a.title, currentRevision: a.currentRevision, targetRef };
    });
    const scopeKey = JSON.stringify([owner, scope]);
    const hasMore = offset + page.length < rows.length;
    const nextCursor = hasMore ? Buffer.from(JSON.stringify({ fingerprint, query, offset: offset + page.length })).toString("base64url") : null;
    this.shown.set(scopeKey, { refs: artworks.map((a) => a.targetRef), hasMore, nextCursor, expiresAt: this.now() + 180_000 });
    for (const [key, value] of this.shown) if (value.expiresAt <= this.now()) this.shown.delete(key);
    return { artworks, hasMore, nextCursor };
  }

  snapshot(owner: string, scope: string) {
    const shown = this.shown.get(JSON.stringify([owner, scope]));
    if (!shown || shown.expiresAt <= this.now()) return this.page(owner, scope);
    const artworks = shown.refs.flatMap((ref) => {
      const target = this.targets.get(ref);
      if (!target || target.expiresAt <= this.now()) return [];
      const a = this.service.getArtwork(owner, target.artworkId);
      return [{ artworkId: a.id, title: a.title, currentRevision: target.expectedBase.revision, targetRef: ref }];
    });
    return { artworks, hasMore: shown.hasMore, nextCursor: shown.nextCursor };
  }

  resolve(owner: string, scope: string, ref: string) {
    const target = this.targets.get(ref);
    if (!target || target.owner !== owner || target.scope !== scope || target.expiresAt <= this.now()) throw new ServiceError(409, "対象参照が失効しました。作品を選び直してください", { code: "target-expired" });
    const current = this.service.getArtwork(owner, target.artworkId);
    const base = current.revisions.find((r) => r.revision === current.currentRevision);
    if (base?.revision !== target.expectedBase.revision || base?.digest !== target.expectedBase.digest) throw new ServiceError(409, "編集元の版が変わっています", { code: "conflict", currentRevision: current.currentRevision, expectedRevision: target.expectedBase.revision });
    return { artworkId: target.artworkId, expectedBase: { ...target.expectedBase } };
  }
}
