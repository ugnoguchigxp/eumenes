// ブラウザ観測の接続口。候補を実際に起動し、起動・操作を画素で確かめる。
import type { ArtworkBody } from "../contract/artwork";
import { ObservationBrowser, playwrightKey } from "./harness-session";
import type { Control } from "./spec";
import type { CheckResult, Observation } from "./types";
import { diffShots, type Shot } from "./pixels";

export interface ObservationResult {
  environment: string;
  checks: CheckResult[];
  observations: Observation[];
}

export interface ObserverPort {
  readonly suite: string;
  observe(body: ArtworkBody, data: unknown, signal: AbortSignal, controls?: readonly Control[]): Promise<ObservationResult>;
  close(): Promise<void>;
}

/** 入力あり・なしを同じseedと時刻で比較し、時間だけの変化を操作応答としない。 */
export const OBSERVER_SUITE = "host-smoke/4";
/** 描画領域のクリックの上限。 */
export const PAINTED_CLICKS = 16;

type IssueToken = (body: ArtworkBody) => string;

export function compareInputRuns(input: readonly Shot[], baseline: readonly Shot[], repeated: readonly Shot[]) {
  const complete = input.length === baseline.length && baseline.length === repeated.length && input.length > 2;
  const deterministic = complete && baseline.every((shot, i) => diffShots(shot, repeated[i]).pixels === 0);
  return { deterministic, responds: deterministic && input.slice(2).some((shot, i) => diffShots(shot, baseline[i + 2]).pixels > 0) };
}

/** Playwright（Chromium）で検証ホストのハーネスを開いて観測する。 */
export class PlaywrightObserver implements ObserverPort {
  readonly suite = OBSERVER_SUITE;
  private readonly browser: ObservationBrowser;
  constructor(private hostOrigin: string, private issue: IssueToken, launchArgs: string[] = [], handleProcessSignals = true) {
    this.browser = new ObservationBrowser(launchArgs, handleProcessSignals);
  }

  async observe(body: ArtworkBody, data: unknown, signal: AbortSignal, controls: readonly Control[] = []): Promise<ObservationResult> {
    signal.throwIfAborted();
    const { PNG } = await import("pngjs");
    signal.throwIfAborted();
    const browser = await this.browser.get();
    signal.throwIfAborted();
    const environment = `chromium ${browser.version()}`;
    const ctx = await browser.newContext({ viewport: { width: 640, height: 480 } });
    const checks: CheckResult[] = [];
    const observations: Observation[] = [];
    const abort = () => ctx.close().catch(() => {});
    signal.addEventListener("abort", abort, { once: true });
    try {
      signal.throwIfAborted();
      const page = await ctx.newPage();
      await page.goto(this.hostOrigin + "/harness.html");
      await page.waitForFunction(() => document.title === "ready", null, { timeout: 10_000 });
      const token = this.issue(body);
      const r = await page.evaluate((a: any) => (window as any).harness.startToken(a), { token, data, seed: 1, clock: "manual", ...(body.runtime === "page" ? { runtime: "page" } : {}) });
      const errors = async () => (await page.evaluate(() => (window as any).harness.events.filter((e: any) => e.type === "error" || e.type === "violation"))) as any[];
      if (r.type !== "ready") {
        const errs = await errors();
        const msg = errs.map((e) => e.message).join(" / ") || (r.type === "timeout" ? "10 秒以内に ready にならない" : r.type);
        checks.push({ id: "boot", level: "loaded", pass: false, detail: msg });
        observations.push({ kind: r.type === "timeout" ? "boot-timeout" : "runtime-error", message: msg });
        return { environment, checks, observations };
      }
      checks.push({ id: "boot", level: "loaded", pass: true });
      const frame = page.locator("#frame");
      const takeShot = async () => PNG.sync.read(await frame.screenshot({ scale: "css" }));
      const shots: Array<{ t: number; shot: Shot }> = [];
      let elapsed = 0;
      const advance = async (ms: number) => { await page.evaluate((n) => (window as any).harness.advance(n), ms); elapsed += ms; };
      const grab = async () => { const shot = await takeShot(); shots.push({ t: elapsed, shot }); return shot; };
      // 段階ごとに画面を撮り、隣どうしを比べる。実行時エラーは最初に出た段階を残す。
      let firstErrorPhase: string | null = null;
      const noteErrors = async (phase: string) => {
        if (!firstErrorPhase && (await errors()).length) firstErrorPhase = phase;
      };
      const s0 = await grab();
      await advance(1000);
      const s1 = await grab();
      await noteErrors("時間の経過（起動から 1000ms）");
      const declared = controls.filter((c) => c.kind === "key").map((c) => c.input);
      const keys = declared.length ? declared : DEFAULT_KEYS;
      const keysAt = 1000 + keys.length * KEY_HOLD_MS;
      const gridAt = keysAt + 500;
      const endAt = gridAt + 500;
      if (declared.length) await page.evaluate(() => (window as any).harness.focus());
      else await frame.click({ position: { x: 240, y: 180 } });
      const keyShots = [s1];
      for (const input of keys) {
        const k = playwrightKey(input);
        await page.keyboard.down(k);
        await advance(KEY_HOLD_MS);
        keyShots.push(await grab()); // 押している間
        await page.keyboard.up(k);
        if (declared.length) keyShots.push(await grab());
      }
      const sk = declared.length ? keyShots[keyShots.length - 1] : await grab(); // 離した直後
      if (!declared.length) keyShots.push(sk);
      await noteErrors(`キー入力（起動から ${keysAt}ms）`);
      // 画面全体に散らした固定点のクリック（座標は観測の文に書かない）
      for (let gy = 0; gy < 4; gy++) for (let gx = 0; gx < 6; gx++) await frame.click({ position: { x: 40 + gx * 80, y: 45 + gy * 90 } });
      await advance(500);
      const s2 = await grab();
      await noteErrors(`画面全体のクリック（起動から ${gridAt}ms）`);
      // 作品が描いた領域（背景色と違う画素のまとまり）の代表点をクリックする
      const targets = paintedTargets(s2, PAINTED_CLICKS);
      for (const p of targets) await frame.click({ position: p });
      await advance(500);
      const s3 = await grab();
      await noteErrors(`描画領域のクリック（起動から ${endAt}ms）`);
      const errs = await errors();
      const keyDiff = keyShots.slice(1).reduce((a, x, i) => a + diff(keyShots[i], x), 0);
      const d = [diff(s0, s1), keyDiff, diff(sk, s2), diff(s2, s3)];
      const baseline = async (): Promise<Shot[]> => {
        const started = await page.evaluate((a: any) => (window as any).harness.startToken(a), { token: this.issue(body), data, seed: 1, clock: "manual", ...(body.runtime === "page" ? { runtime: "page" } : {}) });
        if (started.type !== "ready") return [];
        const out: Shot[] = [];
        let at = 0;
        for (const capture of shots) {
          signal.throwIfAborted();
          if (capture.t > at) await page.evaluate((n) => (window as any).harness.advance(n), capture.t - at);
          at = capture.t;
          out.push(await takeShot());
        }
        return out;
      };
      const comparison = compareInputRuns(shots.map((capture) => capture.shot), await baseline(), await baseline());
      const changed = comparison.responds;
      const varied = colors(s2) > 1;
      const clicked = targets.length ? targets.map((p) => `(${p.x},${p.y})`).join(" ") : "なし（背景以外の描画が見つからない）";
      const keyLabel = declared.length ? `宣言されたキー（${keys.join("・")}）` : "キー（← → ↑ Space）";
      const staticMsg =
        `起動から ${endAt}ms 観測した。段階ごとの差分画素（前の段階の画面との比較）：` +
        `時間の経過 1000ms（入力なし）で ${d[0]}、${keyLabel}を 1 つずつ ${KEY_HOLD_MS}ms 押し続けている間と離した直後に ${d[1]}、` +
        `画面全体に散らした ${GRID_CLICKS} 点のクリックのあと 500ms で ${d[2]}、描画のある領域 ${targets.length} 点のクリックのあと 500ms で ${d[3]}。` +
        `描画領域のクリック座標（CSS px、画面 ${s2.width}×${s2.height}）：${clicked}`;
      if (errs.length) observations.push({ kind: "runtime-error", message: `${firstErrorPhase ? `[${firstErrorPhase}の段階で発生] ` : ""}${errs.map((e) => e.message).join(" / ")}`.slice(0, 1000) });
      if (!varied) observations.push({ kind: "blank", message: `キー入力と画面全体のクリックのあと（起動から ${gridAt}ms）の画面が単色 ${hexAt(s2, 0)} のまま` });
      if (!changed) observations.push({ kind: "static", message: `${comparison.deterministic ? "同じseed・時刻の入力なしの走行との差がありません。" : "入力なしの再現性を確認できず、操作への応答は未確認です。"}${staticMsg}` });
      checks.push({ id: "input-comparison", level: "operated", pass: comparison.deterministic, detail: comparison.deterministic ? undefined : "同じ初期状態と時刻の比較を確認できませんでした" });
      checks.push({ id: "no-runtime-error", level: "operated", pass: errs.length === 0, detail: errs[0]?.message });
      checks.push({ id: "not-blank", level: "operated", pass: varied });
      checks.push({ id: "responds", level: "operated", pass: changed, detail: changed ? undefined : `差分画素 ${d.join("/")}、描画領域のクリック ${targets.length} 点` });
      await page.evaluate(() => (window as any).harness.stop());
      return { environment, checks, observations };
    } finally {
      signal.removeEventListener("abort", abort);
      await ctx.close().catch(() => {});
    }
  }

  close() {
    return this.browser.close();
  }
}

function diff(a: { data: Buffer; width: number; height: number }, b: { data: Buffer }) {
  let d = 0;
  for (let i = 0; i < a.data.length; i += 4) if (a.data[i] !== b.data[i] || a.data[i + 1] !== b.data[i + 1] || a.data[i + 2] !== b.data[i + 2]) d++;
  return d;
}
function colors(a: { data: Buffer }) {
  const set = new Set<number>();
  for (let i = 0; i < a.data.length && set.size < 3; i += 16) set.add((a.data[i] << 16) | (a.data[i + 1] << 8) | a.data[i + 2]);
  return set.size;
}

const GRID_CLICKS = 24;
const DEFAULT_KEYS = ["ArrowLeft", "ArrowRight", "ArrowUp", "Space"];
const KEY_HOLD_MS = 150;

function hexAt(a: { data: Buffer }, i: number) {
  return "#" + [a.data[i * 4], a.data[i * 4 + 1], a.data[i * 4 + 2]].map((v) => v.toString(16).padStart(2, "0")).join("");
}

/**
 * 作品が描いた領域の代表点。最も多い色を背景とし、背景と違う画素が 3 個以上ある 8px のセルを 8 近傍でまとめる。
 * 画面の 1/4 を超えるまとまり（背景の一部とみなす）は除き、大きい順に最大 max 個。
 * 代表点は、まとまりの重心に最も近いセルの中で、セル中心に最も近い背景でない画素。
 */
export function paintedTargets(png: { width: number; height: number; data: Buffer | Uint8Array }, max: number): { x: number; y: number }[] {
  const { width: W, height: H, data } = png;
  const counts = new Map<number, number>();
  for (let i = 0; i < data.length; i += 4) {
    const k = (data[i] << 16) | (data[i + 1] << 8) | data[i + 2];
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  let bg = 0, best = -1;
  for (const [k, n] of counts) if (n > best) { best = n; bg = k; }
  const br = bg >> 16, bgG = (bg >> 8) & 255, bb = bg & 255;
  const fg = (x: number, y: number) => {
    const i = (y * W + x) * 4;
    return Math.abs(data[i] - br) > 24 || Math.abs(data[i + 1] - bgG) > 24 || Math.abs(data[i + 2] - bb) > 24;
  };
  const C = 8, CW = Math.ceil(W / C), CH = Math.ceil(H / C);
  const cell = new Uint8Array(CW * CH);
  for (let cy = 0; cy < CH; cy++)
    for (let cx = 0; cx < CW; cx++) {
      let n = 0;
      for (let y = cy * C; y < Math.min(H, cy * C + C) && n < 3; y++) for (let x = cx * C; x < Math.min(W, cx * C + C) && n < 3; x++) if (fg(x, y)) n++;
      if (n >= 3) cell[cy * CW + cx] = 1;
    }
  const comps: { cells: number[]; sx: number; sy: number; x0: number; y0: number; x1: number; y1: number }[] = [];
  for (let p = 0; p < cell.length; p++) {
    if (cell[p] !== 1) continue;
    const c = { cells: [] as number[], sx: 0, sy: 0, x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    const stack = [p];
    cell[p] = 2;
    while (stack.length) {
      const q = stack.pop()!;
      const qx = q % CW, qy = (q - qx) / CW;
      c.cells.push(q); c.sx += qx; c.sy += qy;
      c.x0 = Math.min(c.x0, qx); c.y0 = Math.min(c.y0, qy); c.x1 = Math.max(c.x1, qx); c.y1 = Math.max(c.y1, qy);
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const nx = qx + dx, ny = qy + dy;
          if (nx < 0 || ny < 0 || nx >= CW || ny >= CH) continue;
          const nq = ny * CW + nx;
          if (cell[nq] === 1) { cell[nq] = 2; stack.push(nq); }
        }
    }
    if ((c.x1 - c.x0 + 1) * (c.y1 - c.y0 + 1) * C * C <= (W * H) / 4) comps.push(c);
  }
  comps.sort((a, b) => b.cells.length - a.cells.length || a.cells[0] - b.cells[0]);
  const out: { x: number; y: number }[] = [];
  for (const c of comps.slice(0, max)) {
    const mx = c.sx / c.cells.length, my = c.sy / c.cells.length;
    let q = c.cells[0], dq = Infinity;
    for (const r of c.cells) {
      const rx = r % CW, ry = (r - rx) / CW, dd = (rx - mx) ** 2 + (ry - my) ** 2;
      if (dd < dq) { dq = dd; q = r; }
    }
    const qx = q % CW, qy = (q - qx) / CW, ccx = qx * C + C / 2, ccy = qy * C + C / 2;
    let pt = { x: Math.min(W - 1, Math.floor(ccx)), y: Math.min(H - 1, Math.floor(ccy)) }, dp = Infinity;
    for (let y = qy * C; y < Math.min(H, qy * C + C); y++)
      for (let x = qx * C; x < Math.min(W, qx * C + C); x++)
        if (fg(x, y)) {
          const dd = (x - ccx) ** 2 + (y - ccy) ** 2;
          if (dd < dp) { dp = dd; pt = { x, y }; }
        }
    out.push(pt);
  }
  return out;
}
