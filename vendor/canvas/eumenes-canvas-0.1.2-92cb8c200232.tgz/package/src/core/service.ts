// 制作コアとテスト用の版保存をつなぐサービス。
// 受付 → 生成 → 候補検査 → ブラウザ観測 →（設定があれば）検証 → 候補提示。保存・復元は所有者・版・世代・digest・検証記録を照合する。
import { randomBytes } from "node:crypto";
import { artworkDigest, checkArtwork, checkData, sha256Hex, type ArtworkBody } from "../contract/artwork";
import { syntaxErrorDetail, withSourceLine } from "./locate";
import type { DatasetInfo, GenerationInput, ModelPort } from "./model-port";
import type { ObserverPort } from "./observer";
import { blockingCount, failedOutcome, findingsAsObservations, type ReviewerPort, type ReviewMode, type ReviewOutcome } from "./review";
import { normalizeSpec } from "./spec";
import { normalizePlan, type EvalPlan } from "./eval-types";
import { ArtworkCatalog } from "./artwork-catalog";
import type { Store } from "./store";
import type { Artwork, Candidate, CheckResult, Observation, Revision, Run, StartRunRequest, Verification } from "./types";
export type { StartRunRequest, ArtworkBase, Run } from "./types";

export const MAX_FIX_ATTEMPTS = 2; // 初回 1 回＋修正 2 回
export const MAX_TURN_INFERENCES = 6; // 複数ターンの制作推論の合計
export const canAcceptConversation = (turns: readonly { role: string }[]) => turns.filter((turn) => turn.role === "user").length < MAX_TURN_INFERENCES;
export type CandidateAccess = (run: Readonly<Run>) => boolean;
const MAX_CONCURRENT_RUNS = 5;

/** 期限までの残りがこれより短いときは検証を始めない。 */
export const REVIEW_MIN_REMAINING_MS = 45_000;

// 必須は段階の名前で数える（matched・advisory は助言で、保存を止めない）
const isRequired = (c: CheckResult) => c.level === "contract" || c.level === "loaded" || c.level === "operated";
/** 必須の段階（contract・loaded・operated）がそろい、すべて合格か。 */
function requiredPassed(checks: CheckResult[]): boolean {
  return ["contract", "loaded", "operated"].every((l) => checks.some((c) => c.level === l)) && checks.filter(isRequired).every((c) => c.pass);
}

export interface Dataset extends DatasetInfo {
  data: unknown;
}

export interface ServiceOptions {
  /** 単一利用者モード。記録の owner を照合せず、全作品・実行・候補を見せる（design.md §3）。 */
  singleUser?: boolean;
  store: Store;
  model: ModelPort;
  observer: ObserverPort;
  contract: string;
  datasets?: Dataset[];
  runTimeoutMs?: number;
  modelCallLimit?: number;
  candidateAccess?: CandidateAccess;
  now?: () => number;
  /** 候補の検証。省略・mode が off なら従来どおり（必須の検査に通った最初の候補を提示する）。 */
  review?: { reviewer: ReviewerPort; mode: ReviewMode; maxReviews?: number };
  /** ページ直接モード（design.md §8）の作品を受け付けるか。既定は偽（runtime は契約の未定義の項目として不合格）。 */
  pageMode?: boolean;
}

export class ServiceError extends Error {
  constructor(public status: number, message: string, public extra: Record<string, unknown> = {}) {
    super(message);
  }
}

const id = (p: string) => p + randomBytes(9).toString("base64url");

export class CanvasService {
  readonly catalog: ArtworkCatalog;
  private aborts = new Map<string, AbortController>();
  private guards = new Map<string, () => boolean>();
  private invalidating = new Map<string, Promise<unknown>>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();
  private closeTask?: Promise<void>;
  private admitting = 0;
  private expiring = new Map<string, Promise<void>>();
  private datasets = new Map<string, Dataset>();
  private now: () => number;
  readonly runTimeoutMs: number;
  /** 実行中の生成（試験で完了を待つため）。 */
  readonly inflight = new Map<string, Promise<void>>();
  private candidateAccess?: CandidateAccess;

  constructor(private o: ServiceOptions) {
    this.candidateAccess = o.candidateAccess;
    this.now = o.now ?? (() => Date.now());
    this.runTimeoutMs = o.runTimeoutMs ?? 180_000;
    this.catalog = new ArtworkCatalog(this, this.now);
    for (const d of o.datasets ?? []) {
      if (!checkData(d.data).ok) throw new Error(`データ ${d.ref} が上限を超える`);
      this.datasets.set(d.ref, d);
    }
  }

  datasetFor(body: ArtworkBody): unknown {
    return body.dataRef ? (this.datasets.get(body.dataRef)?.data ?? null) : null;
  }

  setCandidateAccess(access: CandidateAccess) { this.candidateAccess = access; }

  canUseCandidate(owner: string, candidateId: string): boolean {
    const c = this.o.store.candidates[candidateId];
    const run = c && this.o.store.runs[c.runId];
    if (!c || !this.sees(c.owner, owner) || !run || run.state !== "presented" || run.presentedCandidateId !== c.id) return false;
    try { return this.candidateAccess ? this.candidateAccess(structuredClone(run)) : true; } catch { return false; }
  }

  /** 記録の所有者が要求者と一致するか。単一利用者モードでは常に真（既存記録の owner は書き換えずに無視する）。 */
  private sees(recordOwner: string, owner: string): boolean {
    return !!this.o.singleUser || recordOwner === owner;
  }

  private ownArtwork(owner: string, artworkId: string): Artwork {
    const a = this.o.store.artworks[artworkId];
    if (!a || !this.sees(a.owner, owner)) throw new ServiceError(404, "作品が見つからない");
    return a;
  }

  // ---- 受付 ----
  async startRun(owner: string, session: string, req: StartRunRequest, canAdopt?: () => boolean): Promise<Run> {
    if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
    if (typeof req.message !== "string" || !req.message.trim() || req.message.length > 4000) throw new ServiceError(400, "依頼は 1〜4000 文字");
    const conversation = req.conversation ?? [];
    if (!Array.isArray(conversation) || conversation.length > 20 || conversation.some((t) => !t || !["user", "assistant"].includes(t.role) || typeof t.text !== "string" || !t.text.trim() || t.text.length > 4000))
      throw new ServiceError(400, "会話の形式または上限", { code: "input-capacity" });
    if (req.requestKey !== undefined && (typeof req.requestKey !== "string" || !/^[A-Za-z0-9:_-]{1,200}$/.test(req.requestKey)))
      throw new ServiceError(400, "受付キーの形式");
    if (req.modelCallLimit !== undefined && (!Number.isSafeInteger(req.modelCallLimit) || req.modelCallLimit < 1)) throw new ServiceError(400, "推論予算の形式");
    const modelCallLimit = Math.min(req.modelCallLimit ?? Infinity, this.o.modelCallLimit ?? Infinity);
    const authority = req.authority ?? { kind: "direct" as const };
    if (authority.kind !== "direct" && (authority.kind !== "external" || typeof authority.ref !== "string" || !authority.ref || authority.ref.length > 200)) throw new ServiceError(400, "採用元の形式");
    const requestDigest = req.requestKey ? await sha256Hex(JSON.stringify({ session, message: req.message, conversation, artworkId: req.artworkId ?? null, expectedBase: req.expectedBase ?? null, modelCallLimit: Number.isFinite(modelCallLimit) ? modelCallLimit : null, authority })) : undefined;
    const replay = () => {
      const prior = req.requestKey ? this.findRunByRequest(owner, req.requestKey) : null;
      if (prior && prior.requestDigest !== requestDigest) throw new ServiceError(409, "同じ受付キーで別の制作", { code: "request-conflict" });
      return prior;
    };
    const prior = replay();
    if (prior) return prior;
    if (!canAcceptConversation(conversation)) throw new ServiceError(429, "複数ターンの上限");
    const isNew = !req.artworkId;
    const artworkId = req.artworkId ? this.ownArtwork(owner, req.artworkId).id : id("a_");
    // 取消済みでも、下流が終了するまで枠を返さない。
    if (this.inflight.size + this.admitting >= MAX_CONCURRENT_RUNS) {
      throw new ServiceError(429, "制作の同時実行数が上限です。実行が終わってから再試行してください", { code: "run-capacity" });
    }
    this.admitting++;
    const superseded: string[] = [];
    let base: Revision | undefined;
    let run: Run;
    let fresh = false;
    try {
      run = await this.o.store.write((commit) => {
        if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
        const concurrent = replay();
        if (concurrent) return concurrent;
        if (!isNew) {
          const art = this.ownArtwork(owner, artworkId);
          base = this.o.store.revisionsOf(artworkId).find((r) => r.revision === art.currentRevision);
          if (req.expectedBase && (base?.revision !== req.expectedBase.revision || base?.digest !== req.expectedBase.digest))
            throw new ServiceError(409, "編集元の版が変わっています", { code: "conflict", currentRevision: art.currentRevision, expectedRevision: req.expectedBase.revision });
        } else if (req.expectedBase) {
          throw new ServiceError(400, "新規制作には編集元の版を指定できません");
        }
        return commit(["runs", "sessions"], (s) => {
          const generation = this.o.store.nextGeneration(s, owner, session, isNew ? "new" : artworkId);
          // 同じ制作画面の古い実行は撤回する（後から届いた結果を採用しない）
          for (const r of Object.values(s.runs))
            if (r.owner === owner && r.session === session && (isNew ? r.isNew : r.artworkId === artworkId) && r.generation < generation && (r.state === "running" || r.state === "presented")) {
              r.state = "superseded";
              r.finishedAt = this.now();
              superseded.push(r.id);
            }
          const run: Run = {
            id: id("run_"),
            owner,
            session,
            artworkId,
            isNew,
            baseRevision: base?.revision ?? 0,
            baseDigest: base?.digest ?? null,
            generation,
            request: { message: req.message, conversation },
            state: "running",
            deadline: this.now() + this.runTimeoutMs,
            attempts: 0,
            candidateIds: [],
            presentedCandidateId: null,
            failure: null,
            createdAt: this.now(),
            finishedAt: null,
            ...(req.requestKey ? { requestKey: req.requestKey, requestDigest } : {}),
            ...(Number.isFinite(modelCallLimit) ? { modelCallLimit } : {}),
            modelCalls: 0,
            modelCallIds: [],
            authority: structuredClone(authority),
          };
          s.runs[run.id] = run;
          fresh = true;
          return run;
        });
      });
    } finally {
      this.admitting--;
    }
    if (!fresh) return structuredClone(run);
    if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
    for (const runId of superseded) this.aborts.get(runId)?.abort();
    const ac = new AbortController();
    this.aborts.set(run.id, ac);
    if (canAdopt) this.guards.set(run.id, canAdopt);
    this.timers.set(run.id, setTimeout(() => this.expire(run.id), Math.max(0, run.deadline - this.now())));
    const p = this.execute(run.id, base ? structuredClone(base.body) : null, ac.signal).catch(async (error) => {
      console.error("[canvas] 制作の中断", error);
      try {
        await this.finish(run.id, "failed", "制作処理が中断しました");
      } catch {
        // 台帳を書けないときは、getRun が実行の終了を表示する。
      }
    }).finally(async () => {
      await this.expiring.get(run.id);
      await this.invalidating.get(run.id);
      this.invalidating.delete(run.id);
      this.aborts.delete(run.id);
      this.guards.delete(run.id);
      clearTimeout(this.timers.get(run.id));
      this.timers.delete(run.id);
      this.inflight.delete(run.id);
    });
    this.inflight.set(run.id, p);
    return structuredClone(run);
  }

  /** 成功結果とは独立した受付キーによる照会。再起動後の失敗・取消も追跡できる。 */
  findRunByRequest(owner: string, requestKey: string): Run | null {
    const run = Object.values(this.o.store.runs).find((r) => r.owner === owner && r.requestKey === requestKey);
    return run ? structuredClone(run) : null;
  }

  /** 実行が受付時の状態のままで、結果を採用できるか。 */
  private live(runId: string, signal: AbortSignal): boolean {
    if (signal.aborted) return false;
    const r = this.o.store.runs[runId];
    if (!r || r.state !== "running") return false;
    let allowed = false;
    try { allowed = this.guards.get(runId)?.() ?? true; } catch { /* 参照の再照合は失敗時に採用しない。 */ }
    if (!allowed) {
      this.aborts.get(runId)?.abort();
      if (!this.invalidating.has(runId)) this.invalidating.set(runId, this.cancelRun(r.owner, runId).catch(() => {}));
      return false;
    }
    if (this.now() > r.deadline) {
      this.expire(runId);
      return false;
    }
    return true;
  }

  private expire(runId: string): void {
    if (this.closeTask || this.expiring.has(runId) || this.o.store.runs[runId]?.state !== "running") return;
    const expiration = this.o.store.write(async (commit) => {
      if (this.closeTask || this.o.store.runs[runId]?.state !== "running") return;
      try {
        await commit(["runs"], (s) => {
          const next = s.runs[runId];
          next.state = "expired";
          next.finishedAt = this.now();
        });
      } catch (error) {
        console.error("[canvas] 期限切れを記録できませんでした", error);
      }
    }).finally(() => {
      this.expiring.delete(runId);
    });
    this.expiring.set(runId, expiration);
    this.aborts.get(runId)?.abort();
  }

  cancelRun(owner: string, runId: string): Promise<Run> {
    return this.o.store.write(async (commit) => {
      if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
      const r = this.o.store.runs[runId];
      if (!r || !this.sees(r.owner, owner)) throw new ServiceError(404, "実行が見つからない");
      if (r.state === "running" || r.state === "presented") await commit(["runs"], (s) => {
        const next = s.runs[runId];
        next.state = "cancelled";
        next.finishedAt = this.now();
      });
      this.aborts.get(runId)?.abort();
      return structuredClone(this.o.store.runs[runId]);
    });
  }

  getRun(owner: string, runId: string) {
    const r = this.o.store.runs[runId];
    if (!r || !this.sees(r.owner, owner)) throw new ServiceError(404, "実行が見つからない");
    const cands = r.candidateIds.map((c) => this.candidateView(this.o.store.candidates[c]));
    const run = structuredClone(r);
    const interrupted = !this.inflight.has(runId) || this.aborts.get(runId)?.signal.aborted;
    if (run.state === "running" && (this.closeTask || (interrupted && !this.expiring.has(runId)))) {
      run.state = "failed";
      run.failure = this.closeTask ? "ホストの終了で中断" : "実行状態を保存できなかったため中断しました";
    }
    return { ...run, candidates: structuredClone(cands) };
  }

  private candidateView(c: Candidate) {
    const v = c.verificationId ? this.o.store.verifications[c.verificationId] : null;
    return {
      id: c.id,
      runId: c.runId,
      artworkId: c.artworkId,
      baseRevision: c.baseRevision,
      attempt: c.attempt,
      title: c.body.title,
      digest: c.digest,
      changes: c.changes,
      unconfirmed: c.unconfirmed,
      reply: c.reply,
      verification: v ? { id: v.id, requiredPassed: v.requiredPassed, checks: v.checks, failedAt: v.failedAt ?? null, environment: v.environment } : null,
      spec: c.spec ?? null,
      review: c.review ?? null,
    };
  }

  // ---- 生成・検査・観測・検証 ----
  private async recordInference(runId: string, callId: string, signal: AbortSignal) {
    await this.o.store.write((commit) => {
      if (!this.live(runId, signal)) throw new ServiceError(409, "実行が失効しました");
      const run = this.o.store.runs[runId];
      if (run.modelCallIds?.includes(callId)) return;
      if ((run.modelCalls ?? 0) >= (run.modelCallLimit ?? Infinity)) throw new ServiceError(429, "推論予算を使い切りました", { code: "model-budget" });
      return commit(["runs"], (s) => {
        const next = s.runs[runId];
        (next.modelCallIds ??= []).push(callId);
        next.modelCalls = (next.modelCalls ?? 0) + 1;
      });
    });
  }
  // 必須の検査に通った候補を検証し、重い指摘があって試行が残っていれば直させる。
  // 提示はループのあとに 1 回だけ（必須の検査に通った候補のうち、重い指摘が最も少ないもの。同数なら後の候補）。
  private async execute(runId: string, base: ArtworkBody | null, signal: AbortSignal) {
    const run = this.o.store.runs[runId];
    const review = this.o.review && this.o.review.mode !== "off" ? this.o.review : null;
    const maxReviews = review?.mode === "replay" ? Math.min(1, review.maxReviews ?? 1) : review?.maxReviews ?? MAX_FIX_ATTEMPTS + 1;
    let repairPlan: EvalPlan | undefined;
    let reviewsUsed = 0;
    let best: { id: string; blocking: number } | null = null;
    let previous: ArtworkBody | null = null;
    let previousDigest: string | null = null;
    let previousPassed = false;
    let observations: Observation[] = [];
    for (let attempt = 0; attempt <= MAX_FIX_ATTEMPTS; attempt++) {
      if (!this.live(runId, signal)) return;
      const budget = this.o.store.runs[runId];
      if ((budget.modelCalls ?? 0) >= (budget.modelCallLimit ?? Infinity)) break;
      const input: GenerationInput = {
        request: run.request.message,
        conversation: run.request.conversation,
        base,
        baseDigest: run.baseDigest,
        contract: this.o.contract,
        datasets: [...this.datasets.values()].map((d) => ({ ref: d.ref, description: d.description })),
        attempt,
        previous,
        previousDigest,
        observations,
        previousPassed,
        ...(review?.mode === "replay" && !repairPlan && reviewsUsed < maxReviews ? { requestReplay: true } : {}),
      };
      let out;
      await this.recordInference(runId, `maker:${attempt}`, signal);
      if (!this.live(runId, signal)) return;
      try {
        out = await this.o.model.generate(input, signal);
      } catch (e) {
        if (!this.live(runId, signal)) return;
        if (best) return this.present(runId, best.id, signal);
        return this.finish(runId, "failed", "生成に失敗: " + (e as Error).message);
      }
      if (!this.live(runId, signal)) return; // 取消・期限切れ・撤回後に届いた結果は採用しない
      await this.o.store.write((commit) => {
        if (!this.live(runId, signal)) return;
        return commit(["runs"], (s) => { s.runs[runId].attempts = attempt + 1; });
      });
      if (!this.live(runId, signal)) return;
      const contract = checkArtwork(out.body, { pageMode: this.o.pageMode === true });
      const digest = contract.ok ? await artworkDigest(out.body) : "sha256:invalid";
      if (!this.live(runId, signal)) return;
      const candidate: Candidate = {
        id: id("c_"),
        runId,
        owner: run.owner,
        artworkId: run.artworkId,
        baseRevision: run.baseRevision,
        generation: run.generation,
        attempt,
        body: structuredClone(out.body),
        digest,
        changes: String(out.changes ?? "").slice(0, 2000),
        unconfirmed: (out.unconfirmed ?? []).map(String).slice(0, 20),
        reply: String(out.reply ?? "").slice(0, 2000),
        verificationId: null,
        createdAt: this.now(),
        spec: normalizeSpec(out.spec),
        review: null,
      };
      let checks: Verification["checks"];
      let environment = "none";
      let dataDigest: string | null = null;
      if (!contract.ok) {
        checks = [{ id: "contract", level: "contract", pass: false, detail: contract.errors.join(" / ") }];
        // 構文エラーには作品の行と該当行を足す（制作担当に返す文だけ。検証記録の detail は変えない）
        const syntax = contract.errors.some((m) => m.startsWith("構文エラー")) ? syntaxErrorDetail(String(out.body?.entry ?? "")) : null;
        observations = contract.errors.map((m) => ({ kind: "contract" as const, message: syntax !== null && m.startsWith("構文エラー") ? m + " ／ " + syntax : m }));
      } else if (out.body.dataRef && !this.datasets.has(out.body.dataRef)) {
        checks = [{ id: "contract", level: "contract", pass: false, detail: "未登録の dataRef" }];
        observations = [{ kind: "contract", message: `未登録の dataRef: ${out.body.dataRef}` }];
      } else {
        const data = this.datasetFor(out.body);
        let obs;
        try {
          obs = await this.o.observer.observe(out.body, data, signal, candidate.spec?.controls);
        } catch (e) {
          if (!this.live(runId, signal)) return;
          if (best) return this.present(runId, best.id, signal);
          return this.finish(runId, "failed", "観測に失敗: " + (e as Error).message, "observation-failed");
        }
        if (!this.live(runId, signal)) return;
        dataDigest = data === null ? null : "sha256:" + (await sha256Hex(JSON.stringify(data)));
        if (!this.live(runId, signal)) return;
        environment = obs.environment;
        checks = [{ id: "contract", level: "contract", pass: true }, ...obs.checks];
        // 実行時エラーには作品の該当行を足す（制作担当に返す文だけ）
        observations = obs.observations.map((o) => (o.kind === "runtime-error" ? { ...o, message: withSourceLine(o.message, out.body.entry) } : o));
      }
      const requiredOk = requiredPassed(checks);
      let outcome: ReviewOutcome | null = null;
      const remainingCalls = (this.o.store.runs[runId].modelCallLimit ?? Infinity) - (this.o.store.runs[runId].modelCalls ?? 0);
      const reviewCalls = review?.mode === "probes" ? 0 : review?.mode === "full" ? 2 : 1;
      const firstReview = reviewsUsed < maxReviews && run.deadline - this.now() >= REVIEW_MIN_REMAINING_MS && remainingCalls >= reviewCalls;
      if (requiredOk && review && (firstReview || repairPlan)) {
        if (!repairPlan) reviewsUsed++;
        const plan = review.mode === "replay" ? repairPlan ?? normalizePlan({ scripts: [out.replay] }, candidate.spec ?? null) : undefined;
        const t0 = this.now();
        try {
          outcome = await review.reviewer.review(
            {
              request: run.request.message, conversation: run.request.conversation, base, body: out.body,
              data: this.datasetFor(out.body), spec: candidate.spec ?? null, mode: review.mode as Exclude<ReviewMode, "off">,
              ...(plan ? { replay: { plan, phase: repairPlan ? "repair" : "initial" } } : {}),
            },
            signal,
            (id) => this.recordInference(runId, `review:${attempt}:${id}`, signal),
          );
        } catch (e) {
          // 検証の失敗は候補の失敗にしない
          outcome = failedOutcome(review.reviewer.suite, String((e as Error)?.message ?? e), this.now() - t0);
        }
        if (!this.live(runId, signal)) return;
        candidate.review = {
          mode: review.mode,
          suite: outcome.suite,
          blocking: blockingCount(outcome.findings),
          findings: outcome.findings.slice(0, 40),
          verdict: outcome.verdict,
          evaluatorCalls: outcome.evaluatorCalls,
          ms: outcome.ms,
          error: outcome.error,
          ...(outcome.replay ? { replay: outcome.replay } : {}),
        };
      }
      const verification = this.makeVerification(digest, dataDigest, environment, [...checks, ...(outcome?.checks ?? [])]);
      candidate.verificationId = verification.id;
      const reviewed = !!candidate.review && !candidate.review.error;
      const blocking = review && !reviewed ? Number.POSITIVE_INFINITY : candidate.review?.blocking ?? 0;
      // 重い指摘がなく再生修正でもなければ、この候補が最終候補。検証記録と同時に提示を確定する。
      const readyToPresent = verification.requiredPassed && !repairPlan && (blocking === 0 || (!best && !reviewed));
      const recorded = await this.o.store.write((commit) => {
        if (!this.live(runId, signal)) return false;
        return commit(["runs", "verifications", "candidates"], (s) => {
          const next = s.runs[runId];
          s.verifications[verification.id] = verification;
          s.candidates[candidate.id] = structuredClone(candidate);
          next.candidateIds.push(candidate.id);
          if (readyToPresent) this.markPresented(next, candidate.id);
          return true;
        });
      });
      if (!recorded || readyToPresent) return;
      previous = out.body;
      previousDigest = digest;
      if (!verification.requiredPassed) {
        previousPassed = false;
        continue;
      }
      if (repairPlan) {
        // 再生できた修正版は要件未判定の候補として提示する。再生の失敗は改善の根拠にしない。
        if (!outcome?.replay || outcome.error) break;
        if (blocking === 0) {
          best = { id: candidate.id, blocking };
          break;
        }
      } else {
        if (!best || blocking <= best.blocking) best = { id: candidate.id, blocking };
        if (outcome?.replay) repairPlan = outcome.replay.plan;
      }
      previousPassed = true;
      observations = findingsAsObservations(outcome?.findings ?? []);
    }
    if (!this.live(runId, signal)) return;
    if (best) return this.present(runId, best.id, signal);
    const last = this.o.store.runs[runId];
    return (last.modelCalls ?? 0) >= (last.modelCallLimit ?? Infinity)
      ? this.finish(runId, "failed", "制作の推論予算を使い切りました", "model-budget")
      : this.finish(runId, "failed", "修正の上限（初回＋2 回）に達した", "attempt-limit");
  }

  private present(runId: string, candidateId: string, signal: AbortSignal) {
    return this.o.store.write((commit) => {
      if (!this.live(runId, signal)) return;
      return commit(["runs"], (s) => this.markPresented(s.runs[runId], candidateId));
    });
  }

  private markPresented(run: Run, candidateId: string) {
    run.presentedCandidateId = candidateId;
    run.state = "presented";
    run.finishedAt = this.now();
  }

  private finish(runId: string, state: "failed", failure: string, failureCode = "generation-failed") {
    return this.o.store.write((commit) => {
      if (this.closeTask || this.o.store.runs[runId]?.state !== "running") return;
      return commit(["runs"], (s) => {
        const next = s.runs[runId];
        next.state = state;
        next.failure = failure;
        next.failureCode = failureCode;
        next.finishedAt = this.now();
      });
    });
  }

  private makeVerification(digest: string, dataDigest: string | null, environment: string, checks: Verification["checks"]): Verification {
    // 必須は段階の名前で数える（matched・advisory は助言で、保存を止めない）
    const failed = checks.filter(isRequired).find((c) => !c.pass);
    return {
      id: id("v_"),
      digest,
      suite: this.o.observer.suite,
      environment,
      dataDigest,
      checks,
      requiredPassed: requiredPassed(checks),
      failedAt: failed?.id,
      createdAt: this.now(),
    };
  }

  // ---- 保存 ----
  private replayReceipt(owner: string, key: string, fingerprint: string) {
    const prior = this.o.store.receipt(owner, key);
    if (!prior) return null;
    if (prior.fingerprint !== fingerprint) throw new ServiceError(409, "同じ受領キーで別の操作", { code: "idempotency-mismatch" });
    return { status: prior.status, result: prior.result, replay: true };
  }

  async save(owner: string, candidateId: string, req: { expectedRevision: number; idempotencyKey: string }) {
    const key = String(req.idempotencyKey ?? "");
    if (!/^[A-Za-z0-9_-]{8,80}$/.test(key)) throw new ServiceError(400, "idempotencyKey の形式");
    const { expectedRevision } = req;
    const fingerprint = `save:${candidateId}:${expectedRevision}`;
    const prior = this.replayReceipt(owner, key, fingerprint);
    if (prior) return prior;
    const candidate = this.o.store.candidates[candidateId];
    if (!candidate || !this.sees(candidate.owner, owner)) throw new ServiceError(404, "候補が見つからない");
    const body = structuredClone(candidate.body);
    const recomputed = await artworkDigest(body);

    return this.o.store.write(async (commit) => {
      if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
      const concurrent = this.replayReceipt(owner, key, fingerprint);
      if (concurrent) return concurrent;
      const c = this.o.store.candidates[candidateId];
      if (!c || !this.sees(c.owner, owner)) throw new ServiceError(404, "候補が見つからない");
      const run = this.o.store.runs[c.runId];
      if (!run || run.state !== "presented" || run.presentedCandidateId !== c.id)
        throw new ServiceError(409, "この候補は採用できない状態", { code: "run-" + (run?.state ?? "missing") });
      if (!this.canUseCandidate(owner, candidateId)) throw new ServiceError(409, "この候補の採用元は無効です", { code: "candidate-unavailable" });
      const v = c.verificationId ? this.o.store.verifications[c.verificationId] : null;
      if (!v || !v.requiredPassed) throw new ServiceError(409, "必須の検証に合格していない", { code: "unverified" });
      if (v.digest !== c.digest || recomputed !== c.digest) throw new ServiceError(409, "検証した digest と一致しない", { code: "digest-mismatch" });
      const art = this.o.store.artworks[c.artworkId];
      if (art && !this.sees(art.owner, owner)) throw new ServiceError(404, "候補が見つからない");
      const current = art?.currentRevision ?? 0;
      if (expectedRevision !== current || c.baseRevision !== current) {
        // 競合。候補は残し、差分の確認に戻す
        throw new ServiceError(409, "現在版が変わっている", { code: "conflict", currentRevision: current, candidateBase: c.baseRevision });
      }
      const result = await commit(["artworks", "revisions", "receipts"], (s) => {
        const t = this.now();
        let a = s.artworks[c.artworkId];
        if (!a) {
          a = { id: c.artworkId, owner, title: body.title, currentRevision: 0, createdAt: t, updatedAt: t };
          s.artworks[a.id] = a;
        }
        const rev: Revision = {
          artworkId: a.id,
          revision: a.currentRevision + 1,
          parent: a.currentRevision || null,
          body,
          digest: c.digest,
          verificationId: v.id,
          candidateId: c.id,
          restoredFrom: null,
          createdAt: t,
        };
        this.o.store.pushRevision(s, rev);
        a.currentRevision = rev.revision;
        a.title = body.title;
        a.updatedAt = t;
        const result = { artworkId: a.id, revision: rev.revision, digest: rev.digest };
        this.o.store.putReceipt(s, { key, owner, fingerprint, status: 200, result });
        return result;
      });
      return { status: 200, result, replay: false };
    });
  }

  // ---- 復元 ----
  async restore(owner: string, artworkId: string, req: { revision: number; expectedRevision: number; idempotencyKey: string }) {
    const key = String(req.idempotencyKey ?? "");
    if (!/^[A-Za-z0-9_-]{8,80}$/.test(key)) throw new ServiceError(400, "idempotencyKey の形式");
    const { revision, expectedRevision } = req;
    const fingerprint = `restore:${artworkId}:${revision}:${expectedRevision}`;
    const prior = this.replayReceipt(owner, key, fingerprint);
    if (prior) return prior;
    this.ownArtwork(owner, artworkId);
    const src = this.o.store.revisionsOf(artworkId).find((r) => r.revision === revision);
    if (!src) throw new ServiceError(404, "版が見つからない");
    const body = structuredClone(src.body);
    const recomputed = await artworkDigest(body);

    return this.o.store.write(async (commit) => {
      if (this.closeTask) throw new ServiceError(503, "ホストを終了しています");
      const concurrent = this.replayReceipt(owner, key, fingerprint);
      if (concurrent) return concurrent;
      const artwork = this.ownArtwork(owner, artworkId);
      if (expectedRevision !== artwork.currentRevision) throw new ServiceError(409, "現在版が変わっている", { code: "conflict", currentRevision: artwork.currentRevision });
      if (recomputed !== src.digest) throw new ServiceError(409, "保存版の digest が一致しない", { code: "digest-mismatch" });
      const result = await commit(["artworks", "revisions", "receipts"], (s) => {
        const t = this.now();
        const a = s.artworks[artworkId];
        const rev: Revision = {
          artworkId: a.id,
          revision: a.currentRevision + 1,
          parent: a.currentRevision,
          body,
          digest: src.digest,
          verificationId: src.verificationId,
          candidateId: null,
          restoredFrom: src.revision,
          createdAt: t,
        };
        this.o.store.pushRevision(s, rev);
        a.currentRevision = rev.revision;
        a.title = body.title;
        a.updatedAt = t;
        const result = { artworkId: a.id, revision: rev.revision, digest: rev.digest, restoredFrom: src.revision };
        this.o.store.putReceipt(s, { key, owner, fingerprint, status: 200, result });
        return result;
      });
      return { status: 200, result, replay: false };
    });
  }

  // ---- 参照 ----
  listArtworks(owner: string) {
    return Object.values(this.o.store.artworks)
      .filter((a) => this.sees(a.owner, owner))
      .sort((x, y) => y.updatedAt - x.updatedAt || x.id.localeCompare(y.id))
      .map((a) => ({ id: a.id, title: a.title, currentRevision: a.currentRevision, updatedAt: a.updatedAt }));
  }

  getArtwork(owner: string, artworkId: string) {
    const a = this.ownArtwork(owner, artworkId);
    return {
      ...a,
      revisions: this.o.store.revisionsOf(a.id).map((r) => ({ revision: r.revision, parent: r.parent, digest: r.digest, restoredFrom: r.restoredFrom, title: r.body.title, createdAt: r.createdAt })),
    };
  }

  /** プレビュー対象の実体を解決する。所有者を照合し、保存版か提示中の候補だけを返す。 */
  resolvePreview(owner: string, src: { candidateId?: string; artworkId?: string; revision?: number }): { body: ArtworkBody; data: unknown } {
    if (src.candidateId) {
      const c = this.o.store.candidates[src.candidateId];
      if (!c || !this.sees(c.owner, owner)) throw new ServiceError(404, "候補が見つからない");
      if (!this.canUseCandidate(owner, src.candidateId)) throw new ServiceError(409, "この候補は利用できません", { code: "candidate-unavailable" });
      const v = c.verificationId ? this.o.store.verifications[c.verificationId] : null;
      // 契約の検査と起動を通った候補だけをプレビューできる
      if (!v || !v.checks.some((k) => k.level === "loaded" && k.pass)) throw new ServiceError(409, "起動を確認していない候補", { code: "not-loaded" });
      return { body: structuredClone(c.body), data: this.datasetFor(c.body) };
    }
    if (src.artworkId) {
      const a = this.ownArtwork(owner, src.artworkId);
      const rev = this.o.store.revisionsOf(a.id).find((r) => r.revision === (src.revision ?? a.currentRevision));
      if (!rev) throw new ServiceError(404, "版が見つからない");
      return { body: structuredClone(rev.body), data: this.datasetFor(rev.body) };
    }
    throw new ServiceError(400, "プレビュー対象がない");
  }

  async drain() {
    await Promise.allSettled([...this.inflight.values()]);
  }

  /** 実行中の作業を止め、観測器（Playwright のブラウザなど）を閉じる。 */
  close(): Promise<void> {
    return this.closeTask ??= Promise.resolve().then(async () => {
      for (const timer of this.timers.values()) clearTimeout(timer);
      this.timers.clear();
      for (const abort of this.aborts.values()) abort.abort();
      // 観測がブラウザの応答を待っていても、ブラウザを閉じれば実行を終えられる。
      const results = await Promise.allSettled([this.drain(), this.o.store.idle(), this.o.observer.close(), this.o.review?.reviewer.close()]);
      const errors = results.flatMap((result) => result.status === "rejected" ? [result.reason] : []);
      if (errors.length) throw new AggregateError(errors, "観測を終了できませんでした");
    });
  }
}
