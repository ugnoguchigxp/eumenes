import { type CanvasService } from "./service";
/** 会話に提示した対象と版の参照。制作受付後はジョブが編集元を保持する。 */
export declare class ArtworkCatalog {
    private service;
    private now;
    private targets;
    private shown;
    constructor(service: CanvasService, now?: () => number);
    page(owner: string, scope: string, input?: {
        query?: string;
        cursor?: string;
    }): {
        artworks: {
            artworkId: string;
            title: string;
            currentRevision: number;
            targetRef: string;
        }[];
        hasMore: boolean;
        nextCursor: string | null;
    };
    snapshot(owner: string, scope: string): {
        artworks: {
            artworkId: string;
            title: string;
            currentRevision: number;
            targetRef: string;
        }[];
        hasMore: boolean;
        nextCursor: string | null;
    };
    resolve(owner: string, scope: string, ref: string): {
        artworkId: string;
        expectedBase: {
            revision: number;
            digest: string;
        };
    };
}
