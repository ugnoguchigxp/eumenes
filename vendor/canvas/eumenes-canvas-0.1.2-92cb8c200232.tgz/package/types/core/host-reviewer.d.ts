import { type EvalVerdict } from "./eval-types";
import type { EvaluatorPort } from "./evaluator-port";
import { type ProbePort } from "./probes";
import { type ReviewerPort, type ReviewFinding, type ReviewInput, type ReviewOutcome } from "./review";
import type { MakerSpec } from "./spec";
import type { CheckResult } from "./types";
/** 要件ごとの検査（level は matched）。 */
export declare function verdictChecks(v: EvalVerdict): CheckResult[];
/** 判定から指摘を作る。fail の要件で同じ要件の指摘が無いものは、重い指摘として足す。 */
export declare function verdictFindings(v: EvalVerdict, spec: MakerSpec): ReviewFinding[];
export declare class HostReviewer implements ReviewerPort {
    private lab;
    private evaluator;
    readonly suite: string;
    constructor(lab: ProbePort, evaluator: EvaluatorPort | null);
    review(input: ReviewInput, signal: AbortSignal, beforeInference?: (id: string) => Promise<void>): Promise<ReviewOutcome>;
    private replay;
    private judge;
    close(): Promise<void>;
}
