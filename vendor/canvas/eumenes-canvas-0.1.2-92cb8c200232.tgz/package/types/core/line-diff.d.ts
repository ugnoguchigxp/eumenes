export interface LineDiff {
    added: number;
    removed: number;
    text: string;
    truncated: boolean;
}
/** 最長共通部分列で行ごとに「同じ・削除・追加」を決め、変更のあった行と前後 2 行だけを並べる。同じ長さなら削除を先に出す。 */
export declare function lineDiff(before: string, after: string, maxLines?: number): LineDiff;
