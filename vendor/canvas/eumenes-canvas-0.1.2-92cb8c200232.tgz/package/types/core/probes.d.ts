import type { ArtworkBody } from "../contract/artwork";
import type { EvalPlan } from "./eval-types";
import { type IssueToken } from "./harness-session";
import { type DiffResult } from "./pixels";
import type { ReviewFinding } from "./review";
import { type ScriptResult } from "./script-runner";
import type { MakerSpec } from "./spec";
import type { CheckResult } from "./types";
export declare const PROBE_SUITE = "host-probe/1";
export declare const PROBE: {
    readonly seed: 1;
    readonly preMs: 1000;
    readonly holdMs: 200;
    readonly postMs: 400;
    readonly pokeCount: 30;
    readonly maxKeys: 6;
    readonly maxPointers: 4;
    readonly longMs: 20000;
    readonly heavyWallMs: 400;
    readonly budgetMs: 20000;
    readonly scriptBudgetMs: 30000;
};
export interface InputEffect {
    id: string;
    kind: "key" | "pointer";
    input: string;
    declared: boolean;
    action: string | null;
    always: boolean;
    point: {
        x: number;
        y: number;
    } | null;
    during: DiffResult;
    after: DiffResult;
    errors: string[];
}
export interface ProbeReport {
    suite: string;
    environment: string;
    ms: number;
    booted: boolean;
    scene: string;
    sceneEnd: string;
    motion: DiffResult | null;
    deterministic: boolean | null;
    dtZero: DiffResult | null;
    inputs: InputEffect[];
    resize: {
        narrowSingleColor: boolean;
        errors: string[];
    } | null;
    longRun: {
        ms: number;
        singleColor: boolean;
        errors: string[];
    } | null;
    errors: string[];
    skipped: string[];
}
export interface ProbePort {
    readonly suite: string;
    probe(body: ArtworkBody, data: unknown, spec: MakerSpec | null, signal: AbortSignal): Promise<ProbeReport>;
    /** 検証担当の台本を順に実行する（07）。 */
    runScripts(body: ArtworkBody, data: unknown, plan: EvalPlan, signal: AbortSignal): Promise<ScriptResult[]>;
    close(): Promise<void>;
}
/** 観測の結果から、制作担当・検証担当に渡す指摘を作る。起動しない作品は必須の検査で落ちるので空。 */
export declare function probeFindings(r: ProbeReport): ReviewFinding[];
/** 検証記録に残す検査（すべて advisory）。info 以外の指摘が付いた id を「問題あり」とする。 */
export declare function probeChecks(r: ProbeReport): CheckResult[];
/** 検証担当が引用できる証拠 id の一覧（probeText の行の順と同じ）。 */
export declare function probeEvidenceIds(r: ProbeReport): string[];
/** 制作担当・検証担当に渡す観測の文。各行の先頭が証拠 id。 */
export declare function probeText(r: ProbeReport): string;
/** Playwright（Chromium）で検証ホストのハーネスを開き、性質を調べる。観測 1 回につき HarnessSession を 1 つ使う。 */
export declare class PlaywrightProber implements ProbePort {
    private hostOrigin;
    private issue;
    readonly suite = "host-probe/1";
    private readonly browser;
    constructor(hostOrigin: string, issue: IssueToken, launchArgs?: string[], handleProcessSignals?: boolean);
    protected getBrowser(): Promise<import("playwright-core").Browser>;
    probe(body: ArtworkBody, data: unknown, spec: MakerSpec | null, signal: AbortSignal): Promise<ProbeReport>;
    /** 台本を 1 つの HarnessSession で順に実行する。全体の実時間が PROBE.scriptBudgetMs を超えたら、残りは実行しない。 */
    runScripts(body: ArtworkBody, data: unknown, plan: EvalPlan, signal: AbortSignal): Promise<ScriptResult[]>;
    close(): Promise<void>;
}
