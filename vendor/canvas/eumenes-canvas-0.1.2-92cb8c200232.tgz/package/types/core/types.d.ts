import type { ArtworkBody } from "../contract/artwork";
import type { CandidateReview } from "./review";
import type { MakerSpec } from "./spec";
/** advisory は性質の観測などの助言の検査（保存の必須にしない）。 */
export type CheckLevel = "contract" | "loaded" | "operated" | "matched" | "advisory";
export interface CheckResult {
    id: string;
    level: CheckLevel;
    pass: boolean;
    detail?: string;
}
export interface Verification {
    id: string;
    digest: string;
    suite: string;
    environment: string;
    dataDigest: string | null;
    checks: CheckResult[];
    /** ホストが必須とした検査（contract・loaded・operated）がすべて合格したか。matched は含まない。 */
    requiredPassed: boolean;
    failedAt?: string;
    createdAt: number;
}
export interface Observation {
    /** probe・evaluator は検証（review）の指摘。必須の検査には通っている。 */
    kind: "contract" | "runtime-error" | "boot-timeout" | "blank" | "static" | "model-error" | "probe" | "evaluator";
    message: string;
}
export interface Artwork {
    id: string;
    owner: string;
    title: string;
    currentRevision: number;
    createdAt: number;
    updatedAt: number;
}
export interface Revision {
    artworkId: string;
    revision: number;
    parent: number | null;
    body: ArtworkBody;
    digest: string;
    verificationId: string;
    candidateId: string | null;
    restoredFrom: number | null;
    createdAt: number;
}
export type RunState = "running" | "presented" | "failed" | "cancelled" | "expired" | "superseded";
export interface Turn {
    role: "user" | "assistant";
    text: string;
}
/** ホストが提示・受付した編集元。実行時に最新版へ置き換えない。 */
export interface ArtworkBase {
    revision: number;
    digest: string;
}
export interface StartRunRequest {
    message: string;
    artworkId?: string | null;
    conversation?: Turn[];
    expectedBase?: ArtworkBase;
    /** ホスト発行の受付キー。本文のハッシュとともにrun自体へ保存する。 */
    requestKey?: string;
    modelCallLimit?: number;
    authority?: {
        kind: "direct";
    } | {
        kind: "external";
        ref: string;
    };
}
export interface Run {
    id: string;
    owner: string;
    session: string;
    artworkId: string;
    isNew: boolean;
    baseRevision: number;
    baseDigest: string | null;
    generation: number;
    request: {
        message: string;
        conversation: Turn[];
    };
    state: RunState;
    deadline: number;
    attempts: number;
    candidateIds: string[];
    presentedCandidateId: string | null;
    failure: string | null;
    failureCode?: string;
    createdAt: number;
    finishedAt: number | null;
    requestKey?: string;
    requestDigest?: string;
    modelCallLimit?: number;
    modelCalls?: number;
    modelCallIds?: string[];
    authority?: StartRunRequest["authority"];
}
export interface Candidate {
    id: string;
    runId: string;
    owner: string;
    artworkId: string;
    baseRevision: number;
    generation: number;
    attempt: number;
    body: ArtworkBody;
    digest: string;
    changes: string;
    unconfirmed: string[];
    reply: string;
    verificationId: string | null;
    createdAt: number;
    /** 制作担当の宣言（要件と操作）。宣言が無い・形が違うときは null。 */
    spec?: MakerSpec | null;
    /** 検証（review）の要約。検証しなかった候補は null。 */
    review?: CandidateReview | null;
}
export interface SaveReceipt {
    key: string;
    owner: string;
    fingerprint: string;
    status: number;
    result: unknown;
}
