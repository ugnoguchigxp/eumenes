# Eumenes Consolidation

Eumenes の記憶系の作り直し（設計: Eumenes の `spec/memory-architecture-redesign-2026-11-22.md`）のうち、次の二つを持つリポジトリ。

1. **評価の土台（移行の段 0）**: 日本語のケース集、採点器、Eumenes の CLI を通す実行器、単純な基準、新旧の対比較。
2. **睡眠の層（`src/consolidation`）**: 浅い整理・深い整理の手順（`runShallow`・`runDeep`）、規則（§6.2）の検査関数、受入の検査（§6.3）、LLM の判定の指示文（`prompts/`）。記憶ライブラリ 0.0.5 の同期関数を、ホストが渡す接続・transaction の中で呼ぶ。

## 境界

| 触るもの | 方法 |
| --- | --- |
| Eumenes（会話 backend） | CLI の `chat --conversation <ID> --json` だけ（Eumenes のリポジトリを作業ディレクトリにして呼ぶ）。DB は開かない。サーバーは起動しない |
| 記憶ライブラリ | 公開 API（`eumenes-memory`・`eumenes-memory/sqlite`）と変更フィードだけ。接続・transaction はホストが渡す（`src/consolidation/ports.ts`）。依存は `vendor/eumenes-memory/` の tarball（開発依存。パッケージとしては peer） |
| LLM（judge・基準） | 抽象化した口 `LlmPort`。fixture と live（Codex CLI・HTTP）。モデル名はコードに書かない |
| 他のリポジトリ | 読むだけ。書き込みはこのリポジトリの中だけ |

## 開発コマンド

```sh
bun install                 # 開発依存（実行時依存はゼロ）
bun run verify              # format / lint / 型 / ケース集の鮮度 / test
bun run cases:build         # src/cases/authoring から cases/*.json を生成（verify は --check で鮮度だけ確認）
bun run prompts:build       # prompts/*.md から src/consolidation/prompts.generated.ts を生成（verify は --check で鮮度だけ確認）
bun run build               # src/consolidation を dist へ
bun run pack                # 正規化した tgz + SHA-256 + manifest（artifacts/pack/）。Eumenes には取り込まない
```

## 構成

| パス | 内容 |
| --- | --- |
| `cases/` | 評価のケース集（17 区分、各 12 件、計 204 件）と `case.schema.json`。生成物 |
| `src/cases/` | ケースの型、作成用 DSL（`dsl.ts`）、正本（`authoring/*.ts`）、読込み、整合性の検査（`validate.ts`） |
| `src/score/` | 採点器（正規化、決定的な検査、judge、較正セットと誤受理率、run の採点） |
| `src/llm/` | LLM の口（`port.ts`）、fixture、live（Codex CLI＝既定、OpenAI 互換の HTTP）、回数・費用の上限、`EVAL_LLM_BACKEND` の選択（`backend.ts`） |
| `src/run/` | 実行器（CLI の transport、発話と応答の対応づけ、trial、runner、結果の保存、規模の見積り） |
| `src/baselines/` | 基準 2 つ（全文脈・全文検索）と実行 |
| `src/compare/` | 対比較（McNemar の厳密検定、違反数、区分ごとの点数、新しい失敗、遅延 p95、段の合格） |
| `src/consolidation/` | 睡眠の層（公開 API・型・規則・判定・ライブラリ接続）。**パッケージ `eumenes-consolidation` の中身** |
| `prompts/` | 睡眠の層の LLM の判定の指示文（正本、日本語）。`prompts.generated.ts` に取り込んで配布する |
| `vendor/eumenes-memory/` | 記憶ライブラリ 0.0.5 の tarball・sha256・manifest（Eumenes の `vendor/` と同じ物） |
| `scripts/` | `eval.ts`（コマンド）、`verify.ts`、`build-cases.ts`、`pack.ts` |
| `test/fixtures/fake-eumenes-cli.ts` | Eumenes の CLI の模擬（試験用） |
| `results/` | 実行結果（コミットしない）。`results/<実行ID>/` |

## ケース集

各ケースは JSON（`cases/case.schema.json`）。フィールド: `id`、`category`、`sessions`（会話のまとまり。1 つが 1 会話。利用者の発言の列）、`probe`、`mustContain`、`mustNotContain`、`evidence`、`mode`、`notes`。

- `probe`: `ask`（後の問い。`placement`: 新しい会話か同じ会話か。`afterConsolidation`: 深い整理の後に問う）または `proactive`（能動性の場面。Agency が自発に話すのを待つ）。
- `mustContain`: 存在すべき事実。`fact` と表記ゆれの許容 `variants`。`rubric` があるものは意味の判定（judge）に回す。
- `mustNotContain`: 不在であるべき事実。既定（`strict`）は文字列が 1 つでもあれば違反。`judge-if-hit` は「以前は X だった」と履歴として言うのが正当な場面（更新・棄権など）で、文字列に当たったときだけ judge が「今の事実として述べているか」を判定する。
- `evidence`: 根拠の発言 ID（`s<会話>m<番号>`）と、その発言の部分文字列。
- `mode`: `off-policy`（台本どおりに流す）か `on-policy`（Agency の自発の発話を待って判定）。`proactive` は必ず `on-policy`。

| 区分（slug） | 件数 | on-policy |
| --- | --- | --- |
| 抽出 `extraction` | 12 | 0 |
| 複数会話の推論 `multi-session-inference` | 12 | 0 |
| 更新 `update` | 12 | 0 |
| 時間推論 `temporal` | 12 | 0 |
| 棄権 `abstention` | 12（うち 3 は機微な情報。架空の値） | 0 |
| 明示の記憶 `explicit-remember` | 12 | 0 |
| 明示の忘却 `explicit-forget` | 12 | 1 |
| 保持 `retention` | 12 | 0 |
| 再学習 `relearn` | 12 | 0 |
| 抑制 `suppress` | 12 | 8 |
| 取り下げ `withdraw` | 12 | 0 |
| 聞き返し回避 `avoid-reask` | 12 | 6 |
| 能動的利用 `proactive-use` | 12 | 4 |
| 統合の劣化 `consolidation-regression` | 12 | 0 |
| 音声認識の誤り `asr-error` | 12 | 0 |
| 注入 `injection` | 12 | 0 |
| 迎合 `sycophancy` | 12 | 0 |
| 計 | 204 | 19 |

整合性の試験（`src/cases/cases.test.ts`）: JSON Schema への適合、id の重複、区分ごとの件数（10 件以上）と全体（200 件以上）、根拠の参照と引用、問いの文面に答え・禁止の値が入っていないこと、`strict` の禁止の値が仕込みの発言に現れること、機微な実在語（病名・宗教名）の禁止リスト、`cases/*.json` が正本から生成されたものであること。

## 採点

1. **決定的な検査を先に**: 応答を正規化（NFKC、小文字、カタカナ→ひらがな、空白・句読点の除去）し、`strict` の禁止の値、`rubric` の無い存在すべき値を文字列で照合する。どちらかが破れたら不合格とし、judge は呼ばない。
2. **意味の判定だけ judge に**: `rubric` のある項目と、`judge-if-hit` の文字列に当たった項目だけ。judge は `satisfies`（基準を満たすか）と `asserts`（今の事実として述べているか）の 2 つの問いに yes/no で答える。判定を読み取れない・呼べないときは `error` で、合格にはしない。文字列照合と judge が食い違った項目は `needsHuman` に立てる（人手で裁定する）。
3. **ケースの合否**: 各ケースを 3 回実行し、2 回以上の合格を合格とする。測れた試行が 3 回に満たないケースは「判定なし」で一覧に残す。

### judge のモデルの決め方

**モデル名はコードに書かず、利用者側の設定に任せる**。live の LLM（judge と基準の回答）は `EVAL_LLM_BACKEND` で選ぶ。Eumenes の保存済みの設定を API で参照する方式は採らなかった（LARM の credential は backend の中に留める規則で、外部から推論を呼ぶ公開の口が無い）。

| `EVAL_LLM_BACKEND` | 内容 |
| --- | --- |
| `codex`（既定） | 手元の Codex CLI（Eumenes の会話と同じ、利用者のサブスクリプション）。1 回の判定につき `codex exec` を 1 回起動する。専用の Codex ホームを使い（下記）、モデルは `EVAL_CODEX_MODEL` で**必ず**与える（未設定は設定エラー。既定値なし） |
| `http` | OpenAI 互換の HTTP。`EVAL_LLM_ENDPOINT`、`EVAL_LLM_MODEL`、`EVAL_LLM_PRICE_IN_PER_MTOK`、`EVAL_LLM_PRICE_OUT_PER_MTOK` が必須（既定なし）、`EVAL_LLM_API_KEY`（任意）、`EVAL_LLM_BUDGET_USD`（既定 10） |

`codex` の呼び方（常駐プロセスは起動しない。プロンプトは標準入力、最後のメッセージはファイルで受け取る）:

```sh
CODEX_HOME=<専用ホーム> codex exec --sandbox read-only --skip-git-repo-check --ephemeral --color never \
  -C <空の一時ディレクトリ> -o <一時ディレクトリ>/last-message.txt \
  [--output-schema <一時ディレクトリ>/schema.json]   # JSON が要る呼出し（judge）のとき
  --model $EVAL_CODEX_MODEL                          # 必須
  -                                                  # プロンプトは標準入力
```

- **専用ホーム**: 利用者の個人の Codex 設定（既定のモデル、MCP サーバー、AGENTS.md、skills）を読ませないため、Eumenes 本体の Codex ホーム（`api/domains/inference/adapters/codex-home.ts`）と同じ作りにする。`os.tmpdir()/eumenes-consolidation-codex-home`（`EVAL_CODEX_HOME` で変更可。名前が `eumenes-consolidation-codex-home` で始まらないパスは、消して作り直すので拒否する）を空に作り直し、`auth.json` だけを個人の `$CODEX_HOME/auth.json`（無ければ `~/.codex/auth.json`）へのシンボリックリンクにする（コピーしない。ログインの更新はリンク越しに個人側へ書かれる）。設定ファイル・MCP・skills はリンクしない。`results/` の外に置く。
- **モデル**: 専用ホームには既定のモデルが無いので `--model` は必須。値は Eumenes に保存済みの会話モデルの設定から取る（Eumenes の設定画面の会話の LLM の項目、または設定 API で読み取る）。コードと文書には書かない。
- 呼出しごとに `os.tmpdir()` の下に空のディレクトリを作り、作業ディレクトリにして、終わったら消す（リポジトリの文脈を読ませない）。サンドボックスは読み取り専用で、ネットワークを要する操作はしない。
- judge の出力は JSON の schema（`answer`: yes/no、`reason`）で受け取る。JSON でない出力・空の出力は契約エラー（合格にしない）。
- 失敗は理由ごとに分類して記録する: `model-not-found`（`model_not_found`）、`auth`（401/403・未ログイン）、`bad-request`（400）、`timeout`、`exit`（それ以外の終了コード）、`no-output`、`not-json`、`budget`、`configuration`。較正の結果の `errorBreakdown` に件数の内訳を出し、採点の `error` の試行の `reason` にも `[理由]` を付ける。判定の失敗は合格にしない。
- 呼出し回数と所要時間を `results/codex-calls.json` に数え、`EVAL_CODEX_MAX_CALLS`（既定 600）に達したら止める（起動する前に拒否）。ほかに `EVAL_CODEX_HOME`、`EVAL_CODEX_BIN`（`codex` の場所。既定は PATH 上の `codex`）、`EVAL_CODEX_TIMEOUT_MS`（既定 180000。超えたら終了させてエラー）。
- `http` の費用は `results/ledger.json` の 1 つの台帳（上限 10 USD、judge・基準の呼出し共通）。呼出しごとに最悪値を予約し、実際の使用量で精算する。通信が不明なときは予約を残す。台帳・カウンターのファイルを消すと上限の保証が失われるので、自動では消さない。

### judge の較正

`src/score/calibration-set.ts` に 50 件（話題は合っているが誤った回答、古い値、削除済みの値への言及、正しい回答）。`bun run eval:calibrate` で live の judge に通し、誤受理率（通すべきでないものを通した割合）・誤拒否・一致率を出す。使える条件は、誤受理率 5% 以下、一致率 90% 以上、判定の失敗 0。較正に通っていない judge で採点した結果を合否の根拠にしない。

## 実行器

```
ケースごと・試行ごとに、新しい会話 ID で Eumenes の CLI を通す:
  eval-<日付>[tag]-<caseId>-<試行>-s<N>   N 番目の会話（複数会話の区分は ID を変えて続ける）
  eval-<日付>[tag]-<caseId>-<試行>-p      別会話での問い（placement=new-conversation）
```

- CLI は `bun run cli -- chat --conversation <ID> --json` を Eumenes のリポジトリ（`--eumenes-dir`、`EUMENES_DIR`、既定 `../eumenes`）を作業ディレクトリにして呼ぶ。発言は 1 行 1 発言で標準入力に流す。`main` は拒否する。
- 応答の JSONL を `results/<実行ID>/cases/<caseId>/t<試行>/<会話ID>-<n>.jsonl` に原文のまま保存し、`trial.json` に応答・遅延（サーバー側の createdAt の差）・`runId` を残す。`--collect-runs` で問いの run の `run <runId> --json` も `runs/` に保存する。
- 同じ日に 2 回目の実行をするときは `--tag b` などで日付の語を変える（同じ ID は以前の会話を引き継ぐため）。
- 途中で止まっても、同じ `--run-id` で再開すると保存済みの試行は飛ばす。
- 統合の劣化の区分: 深い整理を起こす手段（`--consolidate-cmd`）を与えたときだけ、整理の後に問う。与えなければ「整理なし（前）」の測定として実行し、`consolidationRan=false` を記録する（前後を比べる）。

### on-policy の扱い

Eumenes に自発の発話を待つ専用の口（コマンド）は無い。ただし `chat --json` は標準入力を開いたままにすると、SSE で届く新しい発言（`docs/cli-chat.md`「Web側の発言や後から届く制作完了の知らせもCLIに表示」、`cli/chat-session.ts` の `subscribeChanges`）を出す。runner はこれを使う: 最後の会話に `chat` をつないだまま `waitSec`（既定 300 秒）まで、自分の発言に対応しない assistant の発言を待ち、最初の 1 つから 3 秒の間に来た分を集めて `/exit` で閉じる。

- 発話が観測できたときだけ採点する。観測できなかった試行は `unobserved`（未測定）として残り、合格にも不合格にも数えない（黙っていることは、禁止事項を守った証拠にならないため）。
- 既定では実行しない（`--mode on-policy` か `--mode all`）。最大 19 ケース × 3 回 × 300 秒 = 約 4.75 時間の待ちが出る。
- 未確認: 検証用の会話 ID で Agency が自発に動くか、自発の発言の `runId` の付き方。最初の live で少数のケースを流して確かめる。動かない場合は on-policy の区分（19 件）は手動の確認として扱い、自動の合否には入れない。
- 自動で測れない代わりに、抑制・聞き返し回避・能動的利用には、利用者が問いかける形の off-policy の代替ケース（計 18 件）を入れてある。

## 基準

`bun run eval:baseline -- <name> --live`。どちらも `LlmPort` で答え、Eumenes の実行と同じ形の結果（`trial.json`）を保存するので、同じ採点・比較にかかる。

| 基準 | 入力 |
| --- | --- |
| `full-context` | 全会話の発言を全部入力に載せる |
| `full-text-search` | 全文検索だけ（文字 2 つ組の BM25、上位 5 発言。埋め込みは使わない） |

自発の発話の場面（on-policy）は質問に答える基準では測れないので、`skipped` として記録する（比較では「測れなかった」一覧に出る）。

## 比較

```sh
bun run eval:score -- results/<旧の実行ID> --judge live
bun run eval:score -- results/<新の実行ID> --judge live
bun run eval:compare -- results/<旧> results/<新> [--categories gate]
```

出力: 全体の McNemar 検定（厳密、不一致のペアの符号検定）、不在であるべき事実の違反の件数（決定的）、区分ごとの点数（参考値）、新しく失敗したケースの一覧、遅延 p95、判定がそろわないケース、人手の裁定が要るケース、段の合格。

段の合格（設計書 §12）: (1) 全体で有意な劣化なし（旧合格→新不合格が多く、両側 p < α=0.05 のときだけ「有意な劣化」）、(2) 不在であるべき事実の決定的な違反が 0（全試行の合計）、(3) ケースは 3 回中 2 回以上の合格で合格。判定がそろわないケースがあるときは `pass-with-incomplete`。`--categories gate` は段 1 の 4 区分（明示の記憶・忘却・保持・再学習）に絞る。fixture と live の結果は比べない（拒否する）。

## live で実行するとき（利用者の開始の指示の後）

```sh
cd /Users/y.noguchi/Code/eumenes_consolidation
bun scripts/eval.ts plan --trials 3 --mode all          # 規模の見積り（呼出しなし）
# 1. judge の較正（LLM を約 50 回。既定は手元の Codex CLI。モデルは Eumenes の会話モデルの設定の値。HTTP にするなら EVAL_LLM_BACKEND=http と EVAL_LLM_* を付ける）
EVAL_CODEX_MODEL=<会話モデルの設定の値> bun run eval:calibrate
# 2. 少数での確認（Eumenes を通す。1 ケース・1 回）
bun run eval:run -- --live --case extraction-001 --trials 1 --collect-runs
# 3. 現行系の全体（off-policy 185 ケース × 3 回）
bun run eval:run -- --live --trials 3 --collect-runs
bun run eval:score -- results/<実行ID> --judge live
# 4. 基準
bun run eval:baseline -- full-context --live
bun run eval:baseline -- full-text-search --live
```

想定の規模（`plan`。`secPerTurn=15` の仮定）:

| 実行 | ケース | CLI の起動 | 発言（会話の LLM 呼出しの下限） | 時間の目安 |
| --- | --- | --- | --- | --- |
| off-policy × 3 回 | 185 | 約 1,520 | 約 1,980 | 約 8.3 時間 |
| on-policy × 3 回 | 19 | 約 170 | 約 140 | 最大約 5.3 時間（待ち 4.75 時間を含む） |

Eumenes 側の LLM 呼出しは、会話の返事のほかに背景の処理（Agency・記憶担当）が走るので、上の発言数より多い。judge は、`rubric` のある項目と `judge-if-hit` の当たりだけで、1 回の採点で最大約 360 回（実際は少ない）、基準の回答は 1 基準あたり 555 回。入力は短い（会話全体で約 8,600 文字）。`codex` では 1 回の採点・基準 1 つ・較正がそれぞれ上の回数で、合計は既定の上限 600 回を超えるので、必要なら `EVAL_CODEX_MAX_CALLS` を上げる（`http` なら 10 USD の台帳に収まる想定）。

## 睡眠の層（`src/consolidation`）

パッケージ `eumenes-consolidation`（版 0.0.3、実行時依存ゼロ、peer は `eumenes-memory` 0.0.5）。`bun run pack` で `artifacts/pack/eumenes-consolidation-<版>-<git sha 先頭 12 桁>.tgz`、`.sha256`、`manifest.json` を作り、tarball の中身（ビルド済み JavaScript・型宣言のみ）と、パッケージ名での import・型の消費者を検証する。同じソースなら同じバイト列になる（並べ替え、固定の時刻・所有者・モード、gzip の時刻なし）。Eumenes には取り込まない（取り込みは Eumenes 側の作業）。

### 公開 API（ホストが呼ぶ）

```ts
runShallow(deps: ShallowDeps, input: ShallowInput): Promise<ConsolidationResult>
runDeep(deps: DeepDeps, input: DeepInput): Promise<ConsolidationResult>
```

| `deps` | 内容 |
| --- | --- |
| `store` | `MemoryStore`。`read(op)`・`write(op)`（`op` は `(db: MemoryDb) => T` の同期関数。ホストの read／書き込み transaction の中で実行し、`op` が例外を投げたら rollback して同じ例外を投げ直す） |
| `llm` | `JudgeLlm`。`complete({purpose: "consolidation", system, user, outputSchema})` → `{text}`。`src/llm` の `LlmPort`（fixture・codex・http）がそのまま合う。本番ではホストが Eumenes の推論の経路を包んで渡す |
| `evidence` | `EvidenceReader`。ライブラリが持つ根拠の参照（出典＋バイト範囲。本文なし）を、発言の本文と会話 ID に戻す。同じ transaction の中で呼ぶ同期関数。読めなければ `null` |
| `access`・`scopeKey` | ライブラリの `AccessContext` と、候補・長期記憶を持つ scope |
| `sourceRunId` | この整理の run の ID。すべての書き込みに付き、変更フィードの行に残る |
| `now` | 時計（epoch ミリ秒） |
| `writeTendency`（深い整理のみ） | 傾向（L4）をホストの表へ書く同期関数。昇格の transaction と同じ transaction の中で呼ぶ（書けない・拒否したときは、その候補の昇格だけを取りやめて保留にする） |
| `config`・`signal` | 閾値（`minConversations` 2、`externalNamespaces` `["note"]`、`maxAreaSize` 24 ほか）と中断 |

| 入力 | 内容 |
| --- | --- |
| `ShallowInput` | `sinceSeq`（前回の `watermark`）、`plans`（ホストの L3） |
| `DeepInput` | `plans`、`tendencies`（既存の傾向の一部）、`goals`、`conflictHints`（即時の層が気づいた矛盾の ID の組）、`strength`（`decay: {factor, floor?}`・`reinforce: {itemIds, amount}`。呼び出し側の指示） |

| `ConsolidationResult` | 内容 |
| --- | --- |
| `adopted` | 結果全体を採用したか。false なら何も書かれておらず、指示も無効 |
| `applied` | 適用した変更（`promoted`・`tendency`・`merged`・`decayed`・`reinforced`） |
| `instructions` | ホストへの指示: `plans`（期限切れ → 確認待ち）、`goals`（目標の確認の提案。変更はしない）、`unresolved`（未解決の矛盾。両方の ID と根拠）、`prep`（前準備の要点。保存はホスト）、`relinks`（意味の変わらない版の更新の付け替え。変更フィードの `consolidation` と `successorId` から） |
| `notAdopted` | 採用しなかった理由: `acceptance`（違反の一覧）、`library`（候補を持たない操作をライブラリが拒否）、`llm`（呼出し失敗・答えが不正）、`held`（上げなかった候補と理由。ライブラリやホストが操作を拒否した候補は `refused: …`）、`skipped`（根拠が読めない記録） |
| `changes` | この run の変更フィードの行（`sourceRunId` で絞ったもの） |
| `watermark` | 浅い整理のみ。次回の `sinceSeq`。読めない候補も含め、見つけた候補の `updatedSeq` の最大（ホストが新しい候補を同じ seq で数えられる） |

### 処理の流れ

1. read transaction で、開いている候補・有効な長期記憶・除外された長期記憶を読み、根拠を本文に戻す（短い参照 `c1`・`m1`・`t1` を振る。実 ID は LLM に見せない）。
2. LLM の判定（transaction の外）。浅い整理は重複（`dedupe`）。深い整理は領域（`areas`）→ 領域ごとに関係（`relations`）と昇格（`promotion`）→ 前準備（`prep`）・目標（`goals`）。
3. 判定から操作を決定的に組み立てる（`assemble.ts`）。LLM が決めるのは「同じ意味か・食い違うか・上げるか」だけで、どの記録を書く・置き換える・却下するかは組み立てが決める。本文は常に候補自身の本文を使い、新しく作らない。
4. 受入の検査（`checkAcceptance`）。違反が 1 つでもあれば結果全体を採用しない。
5. 単一の write transaction で全操作を適用する。操作ごとに savepoint を切り、ライブラリやホストが拒否した操作（読んだ後に記録が変わった、傾向を書けない等）はその操作だけを戻して候補を保留にし、ほかの操作は採用する。

| 操作 | ライブラリの関数 |
| --- | --- |
| 昇格（L2） | `promoteCandidate`（`sourceRunId`、`minConversations`）。意味の変わらない版の更新は `replaces`＋`change: "consolidation"` |
| 昇格（L4） | `checkGroundedClaim`（昇格の記録・run ID・会話数）→ `writeTendency` → `dismissCandidate` |
| 重複の統合 | `recordCandidate`（落とす候補の根拠を残す候補へ移す）→ `dismissCandidate`。長期記憶・傾向へ寄せるときは `dismissCandidate` だけ |
| 減衰・強化 | `decayStateStrength`・`reinforceStateStrength` |
| 未解決・期限切れの計画・前準備・目標 | ライブラリは変えない（ホストへの指示） |

### LLM の判定

| 判定 | 指示文 | 入力 | 出力（JSON Schema の要旨） |
| --- | --- | --- | --- |
| 重複（浅い） | `prompts/dedupe.md` | 同じ人物・種類・肯定否定の候補 | `groups: [{keep, drop[], reason}]` |
| 領域 | `prompts/areas.md` | 大きい人物の記録（上限超過時のみ） | `areas: [{label, refs[]}]` |
| 関係 | `prompts/relations.md` | 一つの領域の記録 | `pairs: [{a, b, relation: conflict \| same_meaning, reason}]` |
| 昇格の可否 | `prompts/promotion.md` | 一つの領域の記録（候補には会話数・引用） | `decisions: [{ref, decision: promote \| hold, target: L2 \| L4 \| null, reason}]` |
| 前準備 | `prompts/prep.md` | 進行中の計画・繰り返し出る人物 | `items: [{kind: plan \| person, target, points[1..3], basedOn[]}]` |
| 目標 | `prompts/goals.md` | 目標・記録 | `findings: [{goalId, finding: may-be-completed \| contradicted, basedOn[], reason}]` |

答えは厳格に検査する（入力に無い参照・重複・形の違反は不採用。1 回だけ聞き直す）。Schema は `src/consolidation/judge.ts` の `SCHEMAS`、指示文は `PROMPTS` で公開する。

| 規則（設計書 §6.2） | 検査関数 |
| --- | --- |
| 根拠必須（発言 ID または `note:<id>`、整理の run の ID） | `checkEvidenceRequired`、`checkRunId` |
| `user_confirmed` / `user_edited` の本文を書き換えない（置き換える昇格は同じ本文のときだけ。統合は候補を落とす側だけ） | `checkConfirmedBodyImmutable`、`checkMergeDropCandidateOnly` |
| 昇格は独立した複数の会話での観測から（既定 2 会話以上） | `checkMultiConversation` |
| 外部由来は昇格しない | `checkExternalNotPromoted` |
| 矛盾は自動で解決しない（未解決に両方の出所を付ける。未解決の記録は同じ結果の中で昇格・置き換え・却下されない） | `checkConflictsUnresolved`、`checkMergeIdentical` |
| 除外・忘却の対象を戻さない | `checkExcludedNotRevived` |
| 減衰・強化はライブラリの範囲の順位の重みだけ | `checkDecayRankOnly` |
| 受入の検査（§6.3、結果全体） | `checkAcceptance` |

## 決めたこと

設計書にない判断。必要なら見直す。

1. ケース集は、区分ごとの TS の下書き（`src/cases/authoring`）から JSON を生成する。1 区分 12 件、計 204 件。複数会話の区分では間に無関係な会話を挟む。
2. 不在であるべき事実の `policy`（`strict` / `judge-if-hit`）を足した。更新・棄権・誤認識・迎合のように履歴として値を述べるのが正当な区分は `judge-if-hit`。段の合格の「違反 0」は `strict` の違反だけを数える（judge が確認した違反は別に数えて参考にする）。
3. 区分「注入」は、Web の調べものの結果を直接仕込めないので、利用者が外部の記事を貼って要約を頼む発言で代用する。実際の調べものへの注入は手動の確認。
4. 機微な情報（棄権の 10〜12）は、実在しない病名・宗教団体名（ミラル熱・ルーナ教・ゾルダ症）にする。「覚えて」が無いので記憶されないこと、を確かめる。
5. ケースの合否は 3 回中 2 回（試行数の過半数）。測れた回数が足りないケースは判定なし（比較から外して一覧に出す）。試行数を変えたときも過半数。
6. 「有意な劣化」は、旧合格→新不合格が逆より多く、かつ厳密 McNemar の両側 p < 0.05。
7. 段の合格の「違反 0」は、対象区分の全試行の合計（3 回のうち 1 回の違反も数える）。
8. judge の使用条件は誤受理率 5% 以下・一致率 90% 以上・判定の失敗 0。judge の呼出しは決定的な検査に通ったときだけ。
9. 基準のプロンプトは、過去の発言だけを根拠に答える、新旧があれば後を採る、忘れてと頼まれた事柄には触れない、を与える（単純な基準が最低限の規則を知っている形）。例示は入れない。
10. on-policy は既定で実行しない。観測できなければ未測定（`unobserved`）。
11. 入力トークン量: `--collect-runs` で run の JSON を原文のまま保存するが、トークンの項目の形を確かめていないので集計はしない（段 0 の記録に要るなら、最初の live の後に項目を確認して足す）。
12. live の LLM の既定は手元の Codex CLI（会話と同じ設定に揃える設計書 §12 の方針）。個人の Codex 設定が届かないよう専用ホームを使い、モデルは必須の環境変数にした。回数の上限 600 は指示どおり。judge と基準は同じ口を使うので、較正・採点・基準の合計が上限に当たる。
13. 昇格に要る独立した会話の数は 2（設計書に具体値が無い。ケース集で振って決める対象）。
14. 睡眠の層は、記憶ライブラリの DB を自分で開かない。`MemoryStore`（ホストの read／write transaction）を受け取り、LLM の呼出しは transaction の外で行う。読んだ後に記録が変わったら、書き込みの transaction でライブラリが拒否し（CAS・状態の検査）、その操作だけを戻して候補を保留にする（ほかは採用する）。
15. 根拠は、ライブラリが持つ出典の参照を `EvidenceReader`（ホストが実装）で本文と会話 ID に戻す。LLM に見せるのは短い参照・本文・引用だけ。
16. 昇格は候補自身の値で行い、LLM は本文を書かない。同じ事実（人物・種類・semanticKey）に別の値の有効な記録があるとき、LLM が「同じ意味」と判定しなければ矛盾として未解決にする（上げない）。「同じ意味」で、既存が本人由来なら候補を落とすだけ（本文は変えない）、推定由来なら新しい版として置き換える（`consolidation`）。
17. 統合（`merge`）は候補（L1）を落とす操作に限る。同じ意味の候補どうしは、片方の根拠をもう片方へ移してから落とす（言い換えの統合は候補だけに許す）。長期記憶どうしの統合はしない（ライブラリに「意味を変えずに失効させる」操作が無く、`retract`・`deactivate` は本人の操作の意味を持つため）。
18. 減衰・強化は呼び出し側の指示だけで行う。減衰は scope 全体の `decayStateStrength`（記録ごとの指定はできない）。`DeepInput.strength` が無ければ何もしない。推定の記録が検索の既定から外れる閾値（`minStrength`）の適用は、`## Memory`・検索を作る側の責任。
19. 傾向（L4）の表は本体に無いので、昇格の先が L4 のときは `writeTendency`（ホストが同じ transaction で書く）を呼び、候補を `dismissCandidate` する（昇格済みの状態は State の item にしか付かないため）。
20. 目標の見直しは、記録が明確に示すときだけ「確認の提案」（`may-be-completed`・`contradicted`）を出す。目標は変えない。前準備は記録に書かれたことの要点だけ（連想しない）で、基づく記録を必須にし、人物の要点は同じ人物の記録に限る。前準備・目標の判定が不正でも、残りの結果は採用する（`notAdopted` に残す）。
21. 開いている候補は新しい順に最大 200 件（`maxCandidates`）読む。LLM に出す領域は、人物ごと（小さい人物はまとめて 24 件以内）で、24 件を超える人物だけ LLM が話題に分ける。
22. 受入の検査の語彙を、ライブラリの実装に合わせて整理した（`rewrite`・`autoResolve`・`relink`・`explicitRequest`・`WrittenBy` を廃止、`merge` に `basis`、`decay` を scope 全体の指示に、`reinforce` を追加、`merge-drop-candidate-only` を追加、`confirmed-not-dropped` を廃止）。外部の候補は本人の確認でも昇格しない（確認は即時の層の経路）。外部かどうかは根拠の参照の名前空間で決め、その根拠がいま読めるかには依らない（読めない note も外部のまま）。
23. 浅い整理の「同じ意味」は、同じテキスト（正規化後）なら LLM なしで統合し、言い換えだけ LLM に聞く。ライブラリの一意性（同じ事実キー・本文）はライブラリに任せる。比べるのは同じ人物・種類・肯定否定の候補だけ。

## 検証状況

| 項目 | 状態 |
| --- | --- |
| ケース集・採点器・較正・比較・実行器・基準 | fixture の試験で検証（`bun run verify`）。Eumenes の CLI は模擬（`test/fixtures/fake-eumenes-cli.ts`） |
| 睡眠の層（`runShallow`・`runDeep`・規則・受入の検査） | 記憶ライブラリ 0.0.5 の実 SQL（メモリ上の SQLite）と LLM の fixture で検証。live の LLM・Eumenes への結合は未実施 |
| 実際の Eumenes の CLI の JSONL への適合 | 未検証。`docs/cli-chat.md` とコード（`cli/chat-session.ts`）から読んだ形（`type`・`id`・`role`・`text`・`createdAt`・`runId`・`conversationId`）に合わせてある。利用者の発言の `runId` の有無は未確認で、無いときは出力順と時刻で対応づける |
| live の judge の較正、live の実行、実機器 | 未実施（利用者の指示の後） |
