# Eumenes Memory ホスト導入と復元

配布tgzのJavaScriptと型宣言だけで利用できる。本ガイドは配布物に同梱し、ソースcheckoutを要求しない。モデルを呼ばないライブラリで、ホストが渡すidentity・scope・時計・DB接続を信頼する。外部APIへ直接公開する認証境界ではない。

## boundaries

本体はState台帳、Records、期限付きの再生成資料、依存閉包、忘却と変更フィードを所有する。DB接続・単一Writer・read/write transaction・非同期queue・モデル・アクセス認証・journalファイルはホストが所有する。Procedure、ベクトル検索、会話原文の正本を持たない。

## startup

1. ホスト側で接続を開く。書き込みは同一の直列Writerへ集め、読み取りもsnapshot transactionで囲む。
2. `eumenes-memory/sqlite`の`migrations`をホストの追記専用配列の末尾へ、各要素1本ずつ登録する。既適用の位置やSQLを変更しない。`checkHostMigrations(hostMigrations)`が空配列であることを検査する。
3. ホストのmigration管理で未適用SQLだけをtransaction内で実行する。新規DBの簡単な例は下記。実運用ではschema_migrations等で適用済み位置を記録する。
4. `assertMemorySchema(db)`を呼ぶ。SCHEMA_MISSING／OUTDATED／TOO_NEW／MISMATCHなら読み書きを開始しない。新しいDBへの旧バイナリの差戻しは安全なrollbackではない。
5. DBと別に保管する最新の忘却journalを確認する。既存DBのjournalが無い場合は勝手に空ファイルを作らない。
6. Worker起動前に、write transaction内で`reconcileForgetJournal(db,{contractVersion:2,entries,clock:{atMs}})`を呼ぶ。`inconsistent`ならMemory全利用を停止し、正しいjournal・DBの組を回復する。`feedResyncRequired`なら外部購読カーソルを捨て全再同期する。`hostIntentsToReapply`があれば、同じtransactionの中で各`hostIntent`に対するホスト自身の消去を冪等に再実行する。
7. 全文検索の索引（migration 0009）はSQLite 3.44以上とFTS5が要る。`pragma_compile_options`の`ENABLE_FTS5`と`sqlite_version()`を確かめ、満たさなければ起動しない。版8のDBへ0009を適用すると、既存のactiveなitemを同じtransactionで索引に入れる。起動時にwrite transactionの中で`verifyStateSearchIndex(db)`を呼び、`consistent: false`なら`rebuildStateSearchIndex(db)`で作り直す。索引は削除をtriggerで、追加を本体の書き込み関数で行う派生物で、本文の正本ではない。
8. 以後はwriteをtransaction内の同期関数として呼ぶ。async関数をtransactionへ渡さない。読み出しの複数SQL・ページ列挙の一貫性はホストのread transactionで守る。

Bunで新規の使い捨てDBを準備する最小例。実運用では上記migration管理とjournal存在確認を先に実装する。

```js
import { Database } from "bun:sqlite";
import { migrations, assertMemorySchema, reconcileForgetJournal } from "eumenes-memory/sqlite";
const db = new Database(":memory:");
db.exec("PRAGMA foreign_keys=ON");
db.transaction(() => { for (const migration of migrations) db.exec(migration); })();
assertMemorySchema(db);
const result = db.transaction(() => reconcileForgetJournal(db, {
  contractVersion: 2, entries: [], clock: { atMs: 0 },
}))();
if (result.status !== "ok") throw Error(result.reasonCode);
```

`MemoryDb`は`exec(sql)`、`query(sql).all/get/run(...params)`、`inTransaction`（必須）を持つ同期port。書込系の関数は`inTransaction`が`true`でなければ`NOT_IN_TRANSACTION`で拒否する（値を持たないadapterも拒否する）。Bunではそのまま満たす。Nodeの`node:sqlite`を使用する場合は`prepare`を`query`へ接続し、ホストが開いたtransactionの状態を`inTransaction`で返す。異なるdriverへの互換は実際のadapterで検証する。

## 保存と訂正

Stateは`assertUserState`へsubject、kind、semanticKey、値、出典の本文と引用範囲を渡す。引用とUTF-8 bytes、digest、revision、principal、scopeが一致しなければ拒否する。保存値は出典本文と同義である必要があり、その意味判断はホストのLLMが担う。同じkeyに異なる値がある場合、`replaces:{itemId,revision}`を指定したCASで訂正する。失敗・rejected・blockedを成功として扱わない。

## state-origin

`user_confirmed`／`user_edited`は本人由来の明示操作、`agent_inferred`はホストの推定。推定を本人確認と表示しない。同値の本人確認はoriginを昇格し、同値の推定では降格しない。`validity`や期限は保存するだけで、現在性はホストが`classifyValidity`等で判定する。


同梱のホストは出典に由来（`provenance`、host schema 3。版上げ前の出典は`unknown`）を記録し、itemの根拠の出典からitemの信頼度（`trust`）を計算して表示する。由来は自己申告なので、`user_message`と申告された外部の文は`inferred`として扱われうる。保証されるのは、どの申告でもconfirmedに上がらないことと、`web`などと申告された出典の記憶が確実に`external`になることだけである。
## 忘却とバックアップ復元

`planForget`は読取のみ。plan・journalへの追記・`applyForget`は、単一Writerの同じwrite transactionの中で行う。entryの`seq`/`prevHash`はplan時点のDBのheadの次なので、planとapplyの間に別の忘却が入ると、適用できないentryがjournalに残り、次のreconcileが`JOURNAL_CHAIN_BROKEN`になる。追記では完全な書込み・fsyncを確認してから`applyForget`を呼ぶ。journalへの初回作成・置換ではdirectoryのfsyncも必要。fsyncの間はWriterを保持する。journalの書込みはDBのrollbackでは戻らない。journal後・DB適用前の失敗では利用を止め、起動時reconcileで回復する。

`contractVersion:2`の`planForget`は、同じscopeの複数target（`targets`、最大64件）と、ホスト自身の派生物を忘れる意図`hostIntent`（キー→不透明なIDの配列。本文を入れない）を1つのentry（format 2）にまとめる。`hostIntent`だけで`targets`が無いentryも作れる。`hostIntent`はhashの鎖に入るので、行の偶発的な破損・切り詰め・食い違いをreconcileが検出する。ホストは`applyForget`と同じtransactionで自分の消去を行い、起動時は`hostIntentsToReapply`で返った分だけを再実行する。format 2のentryを一度書いたjournalは、format 2を読めない旧版の本体では開けない（reconcileが入力検査で失敗し、Memoryは止まる）。

古いDBを復元しても最新journalは巻き戻さない。reconcile後、対象の非表示・値の消去・派生物のpendingを確認する。外部派生物がバックアップ後に登録された場合は、外部所有者が依存を再登録してからreconcileする。外部削除を実行し確認するまでreceiptはcompletedにならない。外部確認状態は古いDB復元でpendingへ戻りうる。

journalのhashの鎖は鍵なしで、検出できるのは偶発的な破損・切り詰め・食い違いだけ。悪意のある書き換えの防止は、journalを保護された媒体に置くホストの責任。復元前のDBと短縮journalを同時に戻した状況は本体だけでは検出できない。journalを別の保護された媒体で保持する。deactivateは可逆の停止であり、忘却ではない。忘却は論理消去で、SQLite空き領域・WAL・OS snapshot・ログの物理消去を保証しない。ホストはsecure_delete、checkpoint、VACUUM、バックアップ保持を運用要件に合わせて管理する。

同梱ホストは、忘却を含む書き込みのコミット後と起動時の復元処理後に、Writerの順番で `PRAGMA wal_checkpoint(TRUNCATE)` を実行する。他の読み取りなどで完了できない場合も、コミット済みの忘却結果は維持し、`status` に `checkpointPending: true` を返す。次に書き込みが成功した後に再試行する。独自の `AppPort` で `checkpoint` を実装しない場合、WALの管理は接続を所有するアプリが担う。

<a id="external-connector-acceptance"></a>
### 外部接続の必須受入契約

World、Consolidation、他エージェント、索引・キャッシュ等がMemory由来の情報を保持する接続では、次を接続先ごとに満たす。単一ホストでもDBと外部コピーの復元時点が異なれば同じ制約がある。

1. 外部所有者が`providerRef`・`externalId`・依存先IDの台帳を管理し、コピーの作成・更新・削除に合わせて`registerExternalDependents`／`unregisterExternalDependents`を呼ぶ。台帳はMemoryの古いDBだけから復元する方式にしない。台帳自体も識別子に限定し、本文を残す場合は消去対象に含める。
2. 復元時は通常の読取・書込・外部提供を止め、最新journalを保持する。外部台帳と復元DBを照合し、バックアップ後に増えた依存を再登録してから`reconcileForgetJournal`を実行する。登録不能・台帳欠落・照合不能は復旧未完了として扱う。先にreconcileすると依存先が墓標化され、後からの登録は`TOMBSTONED`で拒否される。その場合、外部所有者が対象コピーを直接削除して不在を検証するまで利用を再開しない。復元DBに依存先が存在しないコピーも、再登録成功を推測せず同じ手順で解決する。
3. receiptの外部対象を冪等に削除し、接続先でIDを照会して不在を確認したときだけ`recordExternalDeletion(..., state: "confirmed")`を記録する。削除要求の受理だけではconfirmedにしない。失敗は`failed`、結果不明は`unverified`として再確認し、完了を推測しない。復元で確認記録がpendingへ戻った場合も不在確認を繰り返す。
4. 接続受入試験では「DBバックアップ→外部コピー作成・依存登録→忘却→旧DB復元→外部依存再登録→journal再適用→pending→外部削除・不在確認→confirmed」を通す。再登録省略でコピーを見落とす対照、削除失敗・結果不明、二重実行、再復元、無関係なコピーの保持も確認する。共通の参照試験は`test/scenario/forget-closure.test.ts`の`external connector restore acceptance contract`。模擬接続の成功は実接続先の受入完了を意味しない。

`completed`は登録済みの依存・送付先の範囲の結果であり、未登録コピーが存在しない証明ではない。`hostIntent`も記録されていない外部コピーを発見しない。物理消去の非保証はこの契約でも変わらず、SQLiteの空き領域・WAL・OSバックアップや外部側の保持領域は各所有者の運用対象となる。

忘却の範囲と前提（ホストの責任）:

- 本体は単一principalを前提に検証している。墓標はprincipalをまたいで効くので、複数principalで同じ出典IDを使わない。
- `state_item`の忘却はそのitemと派生物だけに届く。置き換え前の版も忘れるときは、`readStateFact`で全版を集めて`targets`に渡す。
- `planForget`・`getForgetReceipt`が返す件数と外部派生物は、同じprincipalの閉包全体で、対象のscopeに限らない。
- `applyForget`に渡すのは`planForget`が返したentryだけ。入力はJSON由来のplainなデータにする（Proxyやgetterは検査対象外）。
- memory recordを出典に引用するときは`representation:"text"`を必ず付ける（省略は契約エラー）。

## 同梱ホストの検索、バックアップ、容量

State の全文検索の設計（リポジトリの `spec/state-search-design.md`、2026-11-16 承認）に沿って、同梱のホスト（`eumenes-memory-host`）は次を行う。使い方は [CLIとメモリーMCP](cli-mcp.md)。

- 起動時に、SQLiteの機能（`SQLITE_FEATURE_MISSING`）を確かめ、未適用の核のmigrationを適用し、索引を検査する（件数と対応表、索引の文書が正本と同じこと、FTS5の`integrity-check`。一致しなければ作り直し、その後のcheckpointで古い索引のページをDBファイルに残さない。作り直せなければ`search`だけを止める）。版8の本体へ戻すときは、サーバーを止めてからリポジトリの`packages/host/scripts/rollback-0009.ts <directory>`で索引を消し、版を8に戻す（その後VACUUMする）。
- 全文検索（`search`、MCP `memory_search`）: 核の`searchState`を、無害化した語、件数20件、返すitemのJSONの合計`maxBytes`（既定32768）の上限で呼ぶ。返すitemは`context`と同じ水和と`evidenceStatus`・`trust`を通す。続きのcursorは出さない。
- 忘却の後の`wal_checkpoint(TRUNCATE)`（失敗したら`status`の`checkpointPending`）、操作の受領記録の30日保持（今のepochも対象）。
- `VACUUM INTO`のバックアップ（`backup`、管理用）と、忘却の後の洗い直し、`restore`（完全な写しを作ってchecksumを確かめてから入れ替える）。途中で止まった作成や洗い直しの残り（記録の無いファイル、`.tmp`、`.scrub-*`）は、次のバックアップか洗い直しの後に0で上書きして消す。
- 稼働DBの消失や破損から復元する場合は、事前にサーバーを停止し、`eumenes-memory protect-journal <データディレクトリ> <保護ディレクトリ>` を一度実行する。保護ディレクトリはデータディレクトリの外に作り、本人のみアクセスできるよう権限を `0700` にする。ディスク障害に備える場合は別の記憶装置を使う。その後サーバーを起動して新しいバックアップを作ると、同じストアの印が付く。
- この復元には、ストアの印が付いたバックアップ、元の `owner.json` と `forget.jsonl`、保護先の最新記録が要る。保護先には忘却対象の識別子とハッシュを含む最新の記録を保管する。保護を設定したストアの起動と忘却には、保護先へのアクセスも要る。バックアップ世代の操作で保護先を巻き戻さない。ローカルと保護先がともに古い状態へ戻った場合は、その新旧を判定できない。
- 出典の由来（`provenance`）とitemの信頼度（`trust`）。
- 容量の監視（`status`の`capacity`と`capacityWarnings`、90%での新しいkeyの保存の制限）。
- 外部由来のitemの自動停止と再利用による延長（`host_item_use`、host schema 4、`use`・`expire`・`reactivate`）と、見直しの一覧（`review`、CLIのみ）。

## 再生成資料と容量

`retainRecord`は明示した資料だけを保持する。読取で期限を延長せず、回答等へ採用したrevisionを`useRetainedRecord`で記録して未使用期限を延長する。State・外部依存・送付記録のある資料は更新やevictを拒否するため、所有者が先に依存を解決する。`retainRecord`したoriginを`captureRecord`しても、そのrecordはretentionの対象のまま（送付記録が無ければevictで消える）。永続化するときは、先に`recordId`を指定してevictしてから`captureRecord`する。通常Recordsはevictしない。忘却済み資料の再captureを墓標で拒否する。

## domains

Recordsは本文と版、Stateは台帳と根拠、Temporalは期間判断、Lifecycleは忘却閉包と外部削除を担当する。時間・モデル・外部ツールの判断をSQL層へ追加しない。純粋APIは`eumenes-memory`、永続APIは`eumenes-memory/sqlite`をimportする。

## verification

配布物は型検査・fixture・実SQLiteのWAL／復元・権限境界・独立consumerで検証する。実ホスト結合、合成の固定判断、実モデル評価は別の証拠であり、一つの成功で他の精度を保証しない。具体的な実行環境・到達段階は各リリースの検証記録で確認する。

## development-examples

`bun run memory`、`check:memory`、seed、比較実験はソースcheckout向けで、tgzの実行用APIには含めない。seedや検証用原文・忘却前snapshotは検証資料であり、forgetがそれらを消すものではない。不要な検証ディレクトリは所有者が削除する。
