/** Compatibility facade. Contract owner: extraction. */
export * from "../domains/extraction/contracts/index.ts";
