/** Compatibility facade. Contract owner: lifecycle. */
export * from "../domains/lifecycle/contracts/index.ts";
