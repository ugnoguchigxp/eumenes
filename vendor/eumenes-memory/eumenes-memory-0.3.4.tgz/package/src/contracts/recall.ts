/** Compatibility facade. Contract owner: recall. */
export * from "../domains/recall/contracts/index.ts";
