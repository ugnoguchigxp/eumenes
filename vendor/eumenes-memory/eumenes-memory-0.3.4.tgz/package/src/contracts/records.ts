/** Compatibility facade. Contract owner: records. */
export * from "../domains/records/contracts/index.ts";
