/** Compatibility facade. Contract owner: state. */
export * from "../domains/state/contracts/index.ts";
