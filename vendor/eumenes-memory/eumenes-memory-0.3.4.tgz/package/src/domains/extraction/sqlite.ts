/** Synchronous persistence operations; the host owns the transaction. */
export * from "./repository/index.ts";
