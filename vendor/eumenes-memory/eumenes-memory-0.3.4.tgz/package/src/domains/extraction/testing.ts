/** Test fixtures exposed to integration tests; not a package export. */
export * from "./test/extraction-support.ts";
