/** Pure domain entry. 時計は呼び出し側（ホスト）が渡す。 */
export * from "./contracts/index.ts";
export * from "./service/period.ts";
export * from "./service/evaluate.ts";
