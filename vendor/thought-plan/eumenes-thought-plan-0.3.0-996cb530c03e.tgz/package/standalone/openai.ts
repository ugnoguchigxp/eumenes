import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import type { Response } from "openai/resources/responses/responses";
import { z } from "zod";
import type { LlmPort, LlmRequest } from "../src/llm";

/**
 * The model settings: which model, how hard it thinks, and what it may spend. Model names live in this file
 * only (`config/llm.json`), never in code.
 */
const llmConfigSchema = z
	.object({
		provider: z.literal("openai"),
		model: z.string().min(1),
		effort: z.enum(["none", "minimal", "low", "medium", "high", "xhigh"]),
		/** Room for reasoning on top of the stage's visible answer. */
		thinkingHeadroom: z.number().int().min(0),
		outputCap: z.number().int().min(1),
		timeoutMs: z.number().int().min(1000),
		spend: z
			.object({
				limitUsd: z.number().positive(),
				usdPerMillionTokens: z.record(
					z.string(),
					z
						.object({
							input: z.number().min(0),
							cachedInput: z.number().min(0),
							output: z.number().min(0),
						})
						.strict(),
				),
			})
			.strict(),
	})
	.strict();
export type LlmConfig = z.infer<typeof llmConfigSchema>;

export const defaultLlmConfigPath = join(
	import.meta.dir,
	"..",
	"config",
	"llm.json",
);

export function readLlmConfig(path = defaultLlmConfigPath): LlmConfig {
	return llmConfigSchema.parse(JSON.parse(readFileSync(path, "utf8")));
}

/**
 * A failed model call with a fixed code: what the runner records as the stage's error. `retryable` says the
 * model never answered (connection, rate limit, server error). When an answer arrived but could not be used,
 * `usage`, `model` and `raw` carry what it was, so the failed stage keeps it in the ledger.
 */
export class LlmCallError extends Error {
	constructor(
		readonly code: string,
		readonly retryable: boolean,
		readonly details: {
			readonly model?: string;
			readonly raw?: unknown;
			readonly usage?: {
				readonly inputTokens: number;
				readonly outputTokens: number;
				readonly cacheReadTokens: number;
			};
		} = {},
	) {
		super(code);
		this.name = "LlmCallError";
	}
	get model() {
		return this.details.model;
	}
	get raw() {
		return this.details.raw;
	}
	get usage() {
		return this.details.usage;
	}
}

/** Exported login-shell variables (`zsh -l`); no profile or env file is read here. */
export function openAIKey(
	env: Readonly<Record<string, string | undefined>> = process.env,
): string {
	for (const name of ["OPEN_AI_API_KEY", "OPENAI_API_KEY"]) {
		const value = env[name]?.trim();
		if (value) return value;
	}
	throw new LlmCallError("llm_api_key_missing", false);
}

/** What the calls cost so far; a call that would start past the limit is refused. */
export function createSpendMeter(config: LlmConfig) {
	let spentUsd = 0;
	let calls = 0;
	const price = (model: string) => {
		const rates = config.spend.usdPerMillionTokens[model];
		if (!rates) throw new LlmCallError("llm_price_missing", false);
		return rates;
	};
	price(config.model);
	return {
		assertWithinLimit() {
			if (spentUsd >= config.spend.limitUsd)
				throw new LlmCallError("llm_spend_limit", false);
		},
		record(
			model: string,
			usage: { input: number; cached: number; output: number },
		) {
			const rates = price(model);
			calls++;
			const uncached = Math.max(0, usage.input - usage.cached);
			spentUsd +=
				(uncached * rates.input +
					usage.cached * rates.cachedInput +
					usage.output * rates.output) /
				1_000_000;
		},
		summary: () => ({ calls, spentUsd }),
	};
}
export type SpendMeter = ReturnType<typeof createSpendMeter>;

/**
 * The provider's prompt cache matches a prompt's leading tokens (from 1,024 on) and routes by this key. A
 * session's calls share their leading exchanges, so the session names the key; a call without a session is
 * keyed by its system context. With the session's `cache` off, no key is sent.
 */
export const promptCacheKey = (text: string) =>
	`thought-plan:${createHash("sha256").update(text).digest("hex").slice(0, 32)}`;

/**
 * The session as Responses API input: every earlier exchange (the stage's system context as a developer
 * message, its input, the answer) and then this stage's. Each stage's system context sits at its own turn, so
 * the leading exchanges stay the same from stage to stage and the cached prefix carries over.
 */
export function sessionInput(request: LlmRequest<unknown>) {
	const turns = request.session?.turns ?? [];
	return [
		...turns.flatMap((turn) => [
			{ role: "developer" as const, content: turn.system },
			{ role: "user" as const, content: turn.prompt },
			{ role: "assistant" as const, content: turn.output },
		]),
		{ role: "developer" as const, content: request.system },
		{ role: "user" as const, content: request.prompt },
	];
}

function cacheKey(request: LlmRequest<unknown>) {
	if (!request.session) return promptCacheKey(request.system);
	return request.session.cache ? promptCacheKey(request.session.id) : undefined;
}

const textOf = (response: Response) =>
	response.output
		.flatMap((item) =>
			item.type === "message"
				? item.content.flatMap((part) =>
						part.type === "output_text" ? [part.text] : [],
					)
				: [],
		)
		.join("");

function mapError(error: unknown, signal: AbortSignal): never {
	if (signal.aborted || (error instanceof Error && error.name === "AbortError"))
		throw error;
	if (error instanceof LlmCallError) throw error;
	if (error instanceof OpenAI.APIConnectionError)
		throw new LlmCallError("llm_connection", true);
	if (error instanceof OpenAI.APIError)
		throw new LlmCallError(
			`llm_api_${error.status ?? 0}`,
			error.status === 429 || (error.status ?? 0) >= 500,
		);
	throw new LlmCallError("llm_call_failed", false);
}

/**
 * The OpenAI Responses API as the runner's model port, the same call shape `eumenes-agency` uses: strict
 * structured output from the stage's schema, nothing stored on the provider side, the configured model and
 * reasoning effort, and a check that the model that answered is the one configured.
 */
export function createOpenAILlm(
	config: LlmConfig,
	meter: SpendMeter = createSpendMeter(config),
	client = new OpenAI({
		apiKey: openAIKey(),
		maxRetries: 0,
		timeout: config.timeoutMs,
	}),
): LlmPort {
	return {
		async complete(request, signal) {
			meter.assertWithinLimit();
			const started = performance.now();
			try {
				const response = await client.responses.create(
					{
						model: config.model,
						input: sessionInput(request),
						...(cacheKey(request) && { prompt_cache_key: cacheKey(request) }),
						store: false,
						reasoning: { effort: config.effort },
						max_output_tokens: Math.min(
							config.outputCap,
							request.maxOutputTokens + config.thinkingHeadroom,
						),
						text: { format: zodTextFormat(request.schema, "stage_output") },
					},
					{ signal },
				);
				if (!response.usage) throw new LlmCallError("llm_usage_missing", false);
				const usage = response.usage;
				meter.record(response.model, {
					input: usage.input_tokens,
					cached: usage.input_tokens_details.cached_tokens,
					output: usage.output_tokens,
				});
				const details = {
					model: response.model,
					usage: {
						inputTokens: usage.input_tokens,
						outputTokens: usage.output_tokens,
						cacheReadTokens: usage.input_tokens_details.cached_tokens,
					},
				};
				if (response.model !== config.model)
					throw new LlmCallError("llm_model_not_confirmed", false, details);
				if (
					response.output.some(
						(item) =>
							item.type === "message" &&
							item.content.some((part) => part.type === "refusal"),
					)
				)
					throw new LlmCallError("llm_refusal", false, details);
				if (response.status !== "completed")
					throw new LlmCallError(
						response.incomplete_details?.reason === "max_output_tokens"
							? "llm_max_tokens"
							: "llm_incomplete",
						false,
						{ ...details, raw: textOf(response) },
					);
				const text = textOf(response);
				let raw: unknown;
				try {
					raw = JSON.parse(text);
				} catch {
					throw new LlmCallError("llm_output_not_json", false, {
						...details,
						raw: text,
					});
				}
				const parsed = request.schema.safeParse(raw);
				if (!parsed.success)
					throw new LlmCallError("llm_output_schema", false, {
						...details,
						raw,
					});
				return {
					value: parsed.data,
					model: response.model,
					inputTokens: usage.input_tokens,
					outputTokens: usage.output_tokens,
					cacheReadTokens: usage.input_tokens_details.cached_tokens,
					latencyMs: performance.now() - started,
				};
			} catch (error) {
				return mapError(error, signal);
			}
		},
	};
}
